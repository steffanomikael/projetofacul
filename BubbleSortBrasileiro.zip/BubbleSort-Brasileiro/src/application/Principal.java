package application;

import services.FabricaRepositorio;

public class Principal {
	public static void main(String[] args) {
		try {
			FabricaRepositorio repositorio = new FabricaRepositorio();
			repositorio.inserir(32);
			repositorio.inserir(2);
			repositorio.inserir(30);
			repositorio.inserir(-22);
			repositorio.inserir(50);
			repositorio.inserir(99);
			repositorio.inserir(23);
			repositorio.bubbleSort();
			repositorio.imprimir();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
