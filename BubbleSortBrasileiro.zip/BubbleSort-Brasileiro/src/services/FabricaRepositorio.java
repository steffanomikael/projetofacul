package services;

import exceptions.ObjetoJaExistenteException;
import exceptions.ObjetoNaoExistenteException;

public class FabricaRepositorio implements IListaEstatica {
	private static final int MAX_LIST = 100;
	private Integer[] dados = new Integer[MAX_LIST];
	private int tamanhoLista = 0;

	@Override
	public void inserir(Object object) throws ObjetoJaExistenteException {
		if (tamanhoLista == dados.length) {
			throw new RuntimeException("A lista est� cheia!");
		}

		for (int i = 0; i < dados.length; i++) {
			if (dados[i] == null) {
				dados[i] = (Integer) object;
				aumentaTamanho();
				break;
			}
		}

	}

	@Override
	public void remover(Object object) throws ObjetoNaoExistenteException {
		int i = localizarIndice(object);

		if (i == -1) {
			throw new ObjetoNaoExistenteException("O objeto n�o existe!");
		}

		dados[i] = null;
		diminuiTamanho();
		Integer[] temp = new Integer[MAX_LIST];
		int tamanhoTemp = 0;
		for (int i1 = 0; i1 < dados.length; i1++) {
			if (dados[i1] != null) {
				temp[tamanhoTemp++] = dados[i1];
			}
		}

		for (int i1 = 0; i1 < dados.length; i1++) {
			if (dados[i1] != null) {
				dados[i1] = null;
			}
		}

		for (int i1 = 0; i1 < temp.length; i1++) {
			if (temp[i1] != null) {
				dados[i1] = temp[i1];
			}
		}

	}

	public Integer pesquisaLinear(int valor) {
		for (int i = 0; i < this.dados.length; i++) {
			if (this.dados[i] != null) {
				if (this.dados[i] == valor) {
					return this.dados[i];
				}
			}
		}

		return null;
	}

	private int tamanhoLista() {
		int tamanho = 0;
		for (int i = 0; i < this.dados.length; i++) {
			if (this.dados[i] != null) {
				tamanho++;
			}
		}

		return tamanho;
	}

	public Integer pesquisaBinaria(int valor) {
		int inicio = 0, meio = 0, fim;
		fim = tamanhoLista() - 1;

		while (inicio <= fim) {
			meio = (inicio + fim) / 2;
			if (valor < this.dados[meio]) {
				fim = meio - 1;
			} else {
				if (valor > this.dados[meio]) {
					inicio = meio + 1;
				} else {
					return this.dados[meio];
				}
			}
		}

		return -1;
	}

	@Override
	public int localizarIndice(Object object) {
		Integer pessoa = (Integer) object;

		for (int i = 0; i < dados.length; i++) {
			if (dados[i] != null && dados[i].equals(pessoa)) {
				return i;
			}
		}

		return -1;
	}

	public void bubbleSort() {
		int tamanhoArray = tamanhoLista();
		int continua;
		do {
			continua = 0;
			for (int i = 0; i < tamanhoArray - 1; i++) {
				if (this.dados[i] > this.dados[i + 1]) {
					Integer temp = this.dados[i + 1];
					this.dados[i + 1] = this.dados[i];
					this.dados[i] = temp;
					continua = i;
				}
			}
		} while (continua != 0);
	}

	@Override
	public Object pesquisarPorValor(Object object) throws ObjetoNaoExistenteException {
		int i = localizarIndice(object);

		if (i == -1) {
			throw new ObjetoNaoExistenteException("O objeto n�o existe!");
		}

		return dados[i];
	}

	@Override
	public void alterar(Object object) throws ObjetoNaoExistenteException {
		int i = localizarIndice(object);
		if (i == -1) {
			throw new ObjetoNaoExistenteException("O objeto n�o existe!");
		}

		dados[i] = (Integer) object;
	}

	public void imprimir() {
		for (int i = 0; i < dados.length; i++) {
			if (dados[i] != null)
				System.out.println(dados[i]);

		}
	}

	private void aumentaTamanho() {
		tamanhoLista++;
	}

	private void diminuiTamanho() {
		tamanhoLista--;
	}
}
