package exceptions;

public class ObjetoJaExistenteException extends Exception {

	private static final long serialVersionUID = 1L;

	public ObjetoJaExistenteException(String mensagemError) {
		super(mensagemError);
	}

}
