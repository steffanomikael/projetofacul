package brasileiro.exercicio3;

public class Principal {
	public static void main(String[] args) {

		Funcionario funcionario = new Funcionario("St�ffano", "123.564.658-02", 660.0);

		Diretor diretor = new Diretor(funcionario, 1, "13-998");
		System.out.println(diretor);
		System.out.println();

		Gerente gerente = new Gerente(funcionario, 1, "98-023");
		System.out.println(gerente);
	}

}
