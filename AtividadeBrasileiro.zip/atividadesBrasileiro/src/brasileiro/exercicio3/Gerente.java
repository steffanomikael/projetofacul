package brasileiro.exercicio3;

public class Gerente extends Funcionario {

	private int qtdFuncionario;
	private String senha;

	public Gerente() {

	}

	public Gerente(Funcionario funcionario, int qtdFuncionario, String senha) {
		super(funcionario.getNome(), funcionario.getCpf(), funcionario.getSalario());
		this.qtdFuncionario = qtdFuncionario;
		this.senha = senha;
	}

	public int getQtdFuncionario() {
		return qtdFuncionario;
	}

	public void setQtdFuncionario(int qtdFuncionario) {
		this.qtdFuncionario = qtdFuncionario;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	@Override
	public String toString() {
		return "Gerente [qtdFuncionario=" + qtdFuncionario + ", senha=" + senha + "]";
	}

}
