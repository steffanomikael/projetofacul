package brasileiro.exercicio3;

public class Diretor extends Funcionario {

	private int qtdFuncionario;
	private String senha;

	public Diretor(Funcionario funcionario, int qtdFuncionario, String senha) {
		super(funcionario.getNome(), funcionario.getCpf(), funcionario.getSalario());
		this.qtdFuncionario = qtdFuncionario;
		this.senha = senha;
	}

	public int getQtdFuncionario() {
		return qtdFuncionario;
	}

	public void setQtdFuncionario(int qtdFuncionario) {
		this.qtdFuncionario = qtdFuncionario;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	@Override
	public String toString() {
		return "Diretor [qtdFuncionario=" + qtdFuncionario + ", senha=" + senha + "]";
	}

}
