package brasileiro.exercicio7;

public class Monitor {

	private String nome;
	private double salario;
	private int horas;

	public Monitor(String nome, double salario, int horas) {
		super();
		this.nome = nome;
		this.salario = salario;
		this.horas = horas;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public int getHoras() {
		return horas;
	}

	public void setHoras(int horas) {
		this.horas = horas;
	}

	public Double getGratificacao() {
		return salario + (horas * 10);
	}

	public String getInfo() {
		return "Professor [nome = " + nome + ", sou monitor com " + horas + "h/aula e Sal�rio R$ " + getGratificacao();
	}
}
