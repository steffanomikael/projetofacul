package brasileiro.exercicio7;

public class Professor {

	private String nome;
	private double salario;
	private int horas;

	public Professor() {

	}

	public Professor(String nome, double salario, int horas) {
		this.nome = nome;
		this.salario = salario;
		this.horas = horas;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public int getHoras() {
		return horas;
	}

	public void setHoras(int horas) {
		this.horas = horas;
	}

	public double getCertificacao() {
		return salario + (horas * 20);
	}

	public String getInfo() {
		return "Professor [nome = " + nome + ", sou professor com " + horas + "h/aula e Sal�rio R$ "
				+ getCertificacao();
	}

}
