package brasileiro.exercicio10;

public interface Ciclista {
	public void pedalar();
}
