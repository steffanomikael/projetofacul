package brasileiro.exercicio10;

public interface Corredor {
	public void correr();
}
