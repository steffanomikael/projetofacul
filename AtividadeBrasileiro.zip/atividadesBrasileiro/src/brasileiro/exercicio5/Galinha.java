package brasileiro.exercicio5;

public class Galinha extends Animal {

	public Galinha(String nome, double peso, String comida) {
		super(nome, peso, comida);
	}

	public void fazerBarulho() {
		System.out.println("Galinha");
	}

	Animal animal = new Animal("Galinha", 2.5, "Ra��o");
}
