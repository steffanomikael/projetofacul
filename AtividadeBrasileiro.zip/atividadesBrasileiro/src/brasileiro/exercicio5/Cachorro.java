package brasileiro.exercicio5;

public class Cachorro extends Animal {

	public Cachorro(String nome, double peso, String comida) {
		super(nome, peso, comida);
	}

	public void fazerBarulho() {
		System.out.println("Cachorro");
	}

	Animal animal = new Animal("Cachorro", 15.5, "Ra��o");
}
