package brasileiro.exercicio1;

public class PessoaJuridica extends Pessoa {

	private String cnpj;
	private String inscricaoEstadual;

	public PessoaJuridica() {

	}

	public PessoaJuridica(Pessoa pessoa, String cnpj, String inscricaoEstadual) {
		super(pessoa.getNome(), pessoa.getEndereco(), pessoa.getCidade(), pessoa.getBairro());
		this.cnpj = cnpj;
		this.inscricaoEstadual = inscricaoEstadual;
	}

	public String getDocumento() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getInscricaoEstadual() {
		return inscricaoEstadual;
	}

	public void setInscricaoEstadual(String inscricaoEstadual) {
		this.inscricaoEstadual = inscricaoEstadual;
	}

	public void FormatarDocumento() {

	}

	@Override
	public String toString() {
		return "PessoaJuridica [cnpj=" + cnpj + ", inscricaoEstadual=" + inscricaoEstadual + "]";
	}

}
