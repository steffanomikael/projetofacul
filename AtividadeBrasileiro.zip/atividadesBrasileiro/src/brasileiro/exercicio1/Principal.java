package brasileiro.exercicio1;

public class Principal {
	public static void main(String[] args) {

		Pessoa pessoa = new Pessoa("St�ffano", "Endere�o", "Recife", "Agua fria");

		PessoaFisica pessoaFisica = new PessoaFisica(pessoa, "123.502.012-05");
		System.out.println(pessoaFisica);
		System.out.println();

		PessoaJuridica pessoaJuridica = new PessoaJuridica(pessoa, "1.235.123.365", "Inscri��o estadual");
		System.out.println(pessoaJuridica);
	}

}
