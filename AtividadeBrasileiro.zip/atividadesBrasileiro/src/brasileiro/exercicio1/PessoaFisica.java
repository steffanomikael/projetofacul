package brasileiro.exercicio1;

public class PessoaFisica extends Pessoa {

	private String cpf;

	public PessoaFisica() {

	}

	public PessoaFisica(Pessoa pessoa, String cpf) {
		super(pessoa.getNome(), pessoa.getEndereco(), pessoa.getCidade(), pessoa.getBairro());
		this.cpf = cpf;
	}

	public String getDocumento() {
		return cpf;
	}

	public void FormatarDocumento() {

	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	@Override
	public String toString() {
		return "PessoaFisica [cpf=" + cpf + "]";
	}

}
