package brasileiro.exercicio2;

public class Chassi {

	private String numero;
	private int ano;

	public Chassi() {

	}

	public Chassi(String numero, int ano) {
		super();
		this.numero = numero;
		this.ano = ano;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	@Override
	public String toString() {
		return "Chassi [numero=" + numero + ", ano=" + ano + "]";
	}

}
