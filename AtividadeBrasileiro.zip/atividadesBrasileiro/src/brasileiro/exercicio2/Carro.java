package brasileiro.exercicio2;

public class Carro {

	private String modelo;
	private int velocidadeMaxima;
	private double segundosZeroACem;
	private Pneu pneu;
	private Motor motor;
	private Chassi chassi;

	public Carro() {

	}

	public Carro(String modelo, int velocidadeMaxima, double segundosZeroACem, Pneu pneu, Motor motor, Chassi chassi) {
		this.modelo = modelo;
		this.velocidadeMaxima = velocidadeMaxima;
		this.segundosZeroACem = segundosZeroACem;
		this.pneu = pneu;
		this.motor = motor;
		this.chassi = chassi;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public int getVelocidadeMaxima() {
		return velocidadeMaxima;
	}

	public void setVelocidadeMaxima(int velocidadeMaxima) {
		this.velocidadeMaxima = velocidadeMaxima;
	}

	public double getSegundosZeroACem() {
		return segundosZeroACem;
	}

	public void setSegundosZeroACem(double segundosZeroACem) {
		this.segundosZeroACem = segundosZeroACem;
	}

	public Pneu getPneu() {
		return pneu;
	}

	public void setPneu(Pneu pneu) {
		this.pneu = pneu;
	}

	public Motor getMotor() {
		return motor;
	}

	public void setMotor(Motor motor) {
		this.motor = motor;
	}

	public Chassi getChassi() {
		return chassi;
	}

	public void setChassi(Chassi chassi) {
		this.chassi = chassi;
	}

	@Override
	public String toString() {
		return "Carro [modelo=" + modelo + ", velocidadeMaxima=" + velocidadeMaxima + ", segundosZeroACem="
				+ segundosZeroACem + ", pneu=" + pneu + ", motor=" + motor + ", chassi=" + chassi + "]";
	}

}
