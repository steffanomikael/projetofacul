package brasileiro.exercicio11;

public class TesteInterface {

	public static void main(String[] args) {
		
		Quadrado quadrado = new Quadrado();
		Cubo cubo = new Cubo();

		imprimirInformacao(quadrado);
		imprimirInformacao(cubo);
	}

	public static void imprimirInformacao(AreaCalculavel CalculandoArea) {
		System.out.println(CalculandoArea.calcularArea());
	}
}