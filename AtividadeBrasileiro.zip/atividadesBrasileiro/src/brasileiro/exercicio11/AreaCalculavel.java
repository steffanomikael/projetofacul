package brasileiro.exercicio11;

public interface AreaCalculavel {
	public double calcularArea();

}
