package br.aeso.application;

public class Q3 {
	public static void main(String[] args) {
		int decimal = 9;
		String binario = converterDecimalParaBinario(decimal);
		StringBuilder builder = new StringBuilder(binario);
		binario = builder.reverse().toString();
		System.out.println(binario);
	}

	private static String converterDecimalParaBinario(int decimal) {
		if (decimal == 1) {
			return String.valueOf(decimal % 2);
		}

		return decimal % 2 + converterDecimalParaBinario(decimal / 2);
	}

}
