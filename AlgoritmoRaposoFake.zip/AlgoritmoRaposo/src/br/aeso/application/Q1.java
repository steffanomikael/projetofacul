package br.aeso.application;

import java.util.Arrays;

public class Q1 {
	public static void main(String[] args) {
		int[] vetor = { 6, 3, 4, 5, 2, 7, 1, 9, 8, 0 };
		quicksort(vetor, 0, vetor.length - 1);
		System.out.println(Arrays.toString(vetor));
	}

	private static void quicksort(int[] vetor, int esquerda, int direita) {
		if (esquerda < direita) {
			int j = separar(vetor, esquerda, direita);
			quicksort(vetor, esquerda, j - 1);
			quicksort(vetor, j + 1, direita);
		}
	}

	private static int separar(int[] vetor, int esquerda, int direita) {
		int i = esquerda + 1;
		int j = direita;
		int pivo = vetor[esquerda];
		while (i <= j) {
			if (vetor[i] <= pivo) {
				i++;
			} else if (vetor[j] > pivo) {
				j--;
			} else if (i <= j) {
				trocar(vetor, i, j);
				i++;
				j--;
			}
		}

		trocar(vetor, esquerda, j);
		return j;
	}

	private static void trocar(int[] vetor, int i, int j) {
		int aux = vetor[i];
		vetor[i] = vetor[j];
		vetor[j] = aux;

	}
}
