package br.aeso.application;

import java.util.Scanner;

public class Q2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		System.out.print("Numero: ");
		int numero = teclado.nextInt();

		int auxiliar = 1;
		int raizQuadrada = 0;

		int tamanho = numero;
		if (numero < 0) {
			tamanho = numero * -1;
		}

		for (int i = 1; i <= tamanho; i++) {
			if (auxiliar % 2 == 0) {
				auxiliar = auxiliar + 1;
			}
			raizQuadrada += auxiliar;
			auxiliar++;
		}

		if (numero < 0) {
			raizQuadrada = raizQuadrada * -1;
		}

		System.out.println(raizQuadrada);

		teclado.close();
	}
}
