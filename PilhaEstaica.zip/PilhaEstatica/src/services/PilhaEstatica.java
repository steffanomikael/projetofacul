package services;

public class PilhaEstatica {
	private Object[] objeto;
	private int posicaoAtual;

	public PilhaEstatica(int tamanho) {
		posicaoAtual = -1;
		objeto = new Object[tamanho];
	}

	public boolean isEmpty() {
		if (posicaoAtual == -1) {
			return true;
		}

		return false;
	}

	public void push(Object object) {
		if (posicaoAtual < this.objeto.length - 1) {
			this.objeto[++posicaoAtual] = object;
		}
	}

	public Object pop() {
		if (isEmpty()) {
			throw new IllegalArgumentException("Pilha is empty!");
		}
		return this.objeto[posicaoAtual--];
	}

}
