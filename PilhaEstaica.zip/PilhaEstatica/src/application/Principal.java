package application;

import services.PilhaEstatica;

public class Principal {
	public static void main(String[] args) {
		PilhaEstatica pilha = new PilhaEstatica(2);
		pilha.push("Lucas");
		System.out.println(pilha.pop());
	}
}
