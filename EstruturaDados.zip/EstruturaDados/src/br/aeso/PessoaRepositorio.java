package br.aeso;

public class PessoaRepositorio implements IListaEstatica{

	@Override
	public void inserir(Object object) {
		
		
	}

	@Override
	public void remover(Object object) {
	
		
	}

	@Override
	public int LocalizarIndice(Object object) {
		
		return 0;
	}

	@Override
	public Object pesquisarPorValor(Object object) {
		
		return null;
	}

	@Override
	public void alterar(Object object) {
		
		
	}

}
