package br.aeso;

public class Pessoa {

	private String cpf;
	private String nome;

	public Pessoa () {
		
	
	}
	
	public Pessoa (String cpf, String nome) {
		this.cpf = cpf.replaceAll("[. ]" , "");
		this.nome = nome;
	}
	
	public String getcpf() {
		return cpf;
	}
		
	public String getcpfFormatado() {
		return format("###.###.###-##", cpf);
		
	}
	
	private String format(String string, String cpf2) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setcpf (String cpf) {
		this.cpf = cpf.replaceAll("[. ]" , "");
		
	}
	
	public String getNome() {
		return nome;
		
	}
	
	public void setNome (String nome) {
		this.nome = nome;
		
	}
	
}

