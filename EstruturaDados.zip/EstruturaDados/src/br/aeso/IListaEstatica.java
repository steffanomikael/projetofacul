package br.aeso;

public interface IListaEstatica {

	public void inserir(Object object);

	public void remover(Object object);

	public int LocalizarIndice(Object object);

	public Object pesquisarPorValor(Object object);

	public void alterar(Object object);
}
