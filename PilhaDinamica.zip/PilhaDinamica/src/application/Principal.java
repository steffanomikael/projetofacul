package application;

import services.PilhaDinamica;

public class Principal {
	public static void main(String[] args) {
		PilhaDinamica dinamica = new PilhaDinamica();
		
		dinamica.push("Maria");
		dinamica.push("Lucas");
		System.out.println(dinamica.pop());
	}
}
