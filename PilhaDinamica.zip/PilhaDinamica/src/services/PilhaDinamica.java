package services;

public class PilhaDinamica {

	private Top top;

	public PilhaDinamica() {
	}

	public void push(String dado) {
		if (isEmpty()) {
			top = new Top(dado);
		} else {
			this.top.push(dado);
		}
	}

	public String pop() {
		if (isEmpty()) {
			throw new IllegalArgumentException("A pilha est� vazia!");
		}

		return this.top.pop().getDado();
	}

	public boolean isEmpty() {
		return top == null ? true : false;
	}

	public boolean isFull() {
		return false;
	}

}
