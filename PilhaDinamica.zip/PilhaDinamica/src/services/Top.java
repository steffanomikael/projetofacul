package services;

public class Top {

	private String dado;
	private Top proximo;
	private Top anterior;

	public Top(String dado) {
		this.dado = dado;
		this.proximo = null;
		this.anterior = null;
	}

	public void push(String dado) {
		if (this.proximo == null) {
			this.proximo = new Top(dado);
			this.proximo.anterior = this;
		} else {
			this.proximo.push(dado);
		}
	}

	public Top pop() {
		if (this.proximo == null && this.anterior != null) {
			Top aux = this.anterior.proximo;
			this.anterior.proximo = null;

			return aux;
		} else if (this.anterior == null && this.proximo == null) {
			Top aux = new Top(this.dado);
			this.dado = null;

			return aux;
		} else {
			return this.proximo.pop();
		}
	}
	
	public String getDado() {
		return dado;
	}

}
