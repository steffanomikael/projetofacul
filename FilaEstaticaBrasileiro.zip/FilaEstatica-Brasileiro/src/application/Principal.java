package application;

import services.FilaEstatica;

public class Principal {

	public static void main(String[] args) {
		FilaEstatica<String> fila = new FilaEstatica<String>(3);
		fila.inserir("St�ffano");
		fila.inserir("Momo");
		fila.inserir("Sana");
		fila.remover();
		fila.inserir("Lucas");

		System.out.println(fila.consultar());
		System.out.println(fila.isEmpty());
		System.out.println(fila.isFull());
	}

}
