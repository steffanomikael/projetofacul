package services;

public class FilaEstatica<T extends Object> {

	private Object[] dados;
	private int inicio;
	private int fim;
	private int quantidade;

	public FilaEstatica(int tamanho) {
		this.dados = new Object[tamanho];
	}

	public void inserir(T dado) {
		if (isFull()) {
			throw new IllegalArgumentException("A fila est� cheia!");
		}

		this.dados[fim] = (Object) dado;
		fim = (fim + 1) % this.dados.length;
		quantidade++;
	}

	public void remover() {
		if (isEmpty()) {
			throw new IllegalArgumentException("A fila est� vazia!");
		}

		this.dados[inicio] = null;
		inicio = (inicio + 1) % this.dados.length;
		quantidade--;
	}

	public Object consultar() {
		if (isEmpty()) {
			throw new IllegalArgumentException("A fila est� vazia");
		}

		return this.dados[inicio];
	}

	public boolean isEmpty() {
		return quantidade == 0 ? true : false;
	}

	public boolean isFull() {
		return quantidade == dados.length ? true : false;
	}

}