package projeto1sd;

import java.util.Scanner;

public class Princiapl {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		try {
			final int QUANTIDADE_DE_ALUNOS = 3;
			float[] nota1 = new float[QUANTIDADE_DE_ALUNOS];
			float[] nota2 = new float[QUANTIDADE_DE_ALUNOS];
			float[] nota3 = new float[QUANTIDADE_DE_ALUNOS];
			float[] media = new float[QUANTIDADE_DE_ALUNOS];

			System.out.println("=============================================");
			System.out.println("Leitura das Informa��es Sobre os Alunos");
			System.out.println("=============================================");
			System.out.println("______________________________________________");
			System.out.println("______________Nota 01_________________________");
			System.out.println("______________________________________________");

			for (int i = 0; i < nota1.length; i++) {
				System.out.printf("Digite a nota 1 do aluno %d: ", i + 1);
				nota1[i] = Float.parseFloat(teclado.next().replace(",", "."));
			}

			System.out.println("______________________________________________");
			System.out.println("______________Nota 02_________________________");
			System.out.println("______________________________________________");

			for (int i = 0; i < nota2.length; i++) {
				System.out.printf("Digite a nota 2 do aluno %d: ", i + 1);
				nota2[i] = Float.parseFloat(teclado.next().replace(",", "."));
			}

			System.out.println("______________________________________________");
			System.out.println("______________Nota 03_________________________");
			System.out.println("______________________________________________");

			for (int i = 0; i < nota3.length; i++) {
				System.out.printf("Digite a nota 3 do aluno %d: ", i + 1);
				nota3[i] = Float.parseFloat(teclado.next().replace(",", "."));
			}

			for (int i = 0; i < media.length; i++) {
				media[i] = ((nota1[i] * 2) + (nota2[i] * 3) + (nota3[i] * 5)) / 10;
			}

			System.out.println("=============================================");
			System.out.println("Listagem dos alunos e suas respectivas m�dias");
			System.out.println("=============================================");

			for (int i = 0; i < media.length; i++) {
				System.out.printf("Aluno: %d\n", i + 1);
				System.out.printf("M�dia: %.1f\n", media[i]);
				System.out.println();
			}

			System.out.println("=============================================");
		} catch (Exception e) {
			System.out.println("Error: valor invalido!");
		}

		teclado.close();
	}
}
