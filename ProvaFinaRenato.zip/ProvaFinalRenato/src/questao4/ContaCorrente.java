package questao4;

public class ContaCorrente {

	private String numeroConta;
	private String nomeCorrentista;
	private Double saldo;

	public ContaCorrente(String numeroConta, String nomeCorrentista, Double saldo) {
		this.numeroConta = numeroConta;
		this.nomeCorrentista = nomeCorrentista;
		this.saldo = saldo;
	}

	public ContaCorrente(String numeroConta, String nomeCorrentista) {
		this.numeroConta = numeroConta;
		this.nomeCorrentista = nomeCorrentista;
	}

	public String getNumeroConta() {
		return numeroConta;
	}

	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	public String getNomeCorrentista() {
		return nomeCorrentista;
	}

	public void setNomeCorrentista(String nomeCorrentista) {
		this.nomeCorrentista = nomeCorrentista;
	}

	public Double getSaldo() {
		return saldo;
	}

	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}

	public void alterarNome(String nome) {
		this.nomeCorrentista = nome;
	}

	public void depositar(double valor) {
		verificandoDeposito(valor);

		this.saldo += valor;
	}

	public void sacar(double valor) {
		verificandoSaque(valor);

		this.saldo -= valor;
	}

	private void verificandoDeposito(double valorDeposito) {
		if (valorDeposito < 0) {
			throw new IllegalArgumentException("O valor n�o pode ser negativo. Digite novamente.");
		}
	}

	private void verificandoSaque(double saque) {
		if (saque < 0) {
			throw new IllegalArgumentException("O saque n�o pode ser negativo. Digite novamente.");
		}

		if (saque > this.saldo) {
			throw new IllegalArgumentException("O saque n�o pode ser maior que o saldo. Digite novamente.");

		}
	}

	@Override
	public String toString() {
		return "ContaCorrente [numeroConta=" + numeroConta + ", nomeCorrentista=" + nomeCorrentista + ", saldo=" + saldo
				+ "]";
	}

}
