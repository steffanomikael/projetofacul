package questao3;

public class BombaCombustivel {
	private Combustivel combustivel;
	private double valorLitro;
	private double quantidadeCombustivel;

	public BombaCombustivel() {
	}

	public BombaCombustivel(Combustivel combustivel, double valorLitro, double quantidadeCombustivel) {
		this.combustivel = combustivel;
		this.valorLitro = valorLitro;
		this.quantidadeCombustivel = quantidadeCombustivel;
	}

	public Combustivel getTipoCombustivel() {
		return combustivel;
	}

	public void setTipoCombustivel(Combustivel tipoCombustivel) {
		this.combustivel = tipoCombustivel;
	}

	public double getValorLitro() {
		return valorLitro;
	}

	public void setValorLitro(double valorLitro) {
		this.valorLitro = valorLitro;
	}

	public double getQuantidadeCombustivel() {
		return quantidadeCombustivel;
	}

	public void setQuantidadeCombustivel(double quantidadeCombustivel) {
		this.quantidadeCombustivel = quantidadeCombustivel;
	}

	public void abastecerPorValor(double valor) {
		double litro = valorLitro / valor;
		this.quantidadeCombustivel += litro;
		System.out.println("Quantidade de litro: " + litro);

	}

	public void abastecerPorLitro(double litro) {
		double total = litro * valorLitro;
		this.quantidadeCombustivel += litro;
		System.out.println("Valor a ser pago: R$ " + total);

	}

	public void alterarCombustivel(Combustivel combustivel) {
		this.combustivel = combustivel;
	}

	public void alterarValor(double valor) {
		this.valorLitro = valor;
	}

	public void alterarQuantidadeCombustivel(double quantidadeCombustivel) {
		this.quantidadeCombustivel = quantidadeCombustivel;
	}
}
