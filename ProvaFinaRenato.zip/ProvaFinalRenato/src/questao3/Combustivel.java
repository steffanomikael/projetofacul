package questao3;

public enum Combustivel {
	ETANOL("Etanol"), GASOLINA("Gasolina"), ALCOOL("Alcool");

	private String descricao;

	private Combustivel(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}
}
