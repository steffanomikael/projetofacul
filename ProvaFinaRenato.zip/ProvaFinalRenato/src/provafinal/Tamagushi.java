package provafinal;

public class Tamagushi {

	private String nome;
	private String fome;
	private String saude;
	private int idade;

	public Tamagushi() {
	}

	public Tamagushi(String nome, String fome, String saude, int idade) {
		setNome(nome);
		setFome(fome);
		setSaude(saude);
		setIdade(idade);
	}

	public String getNome() {
		return nome;
	}

	//pode alterar o nome por meio do set
	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getFome() {
		return fome;
	}

	//verificando se est� com fome
	public void setFome(String fome) {
		if (fome.equalsIgnoreCase("sim")) {
			throw new IllegalArgumentException("Com fome");
		}
		if (fome.equalsIgnoreCase("n�o")) {
			throw new IllegalArgumentException("Sem fome");
		}

		this.fome = fome;
	}

	public String getSaude() {
		return saude;
	}
	
	//verificando se est� com sa�de
	public void setSaude(String saude2) {
		if (saude2.equalsIgnoreCase("sim")) {
			throw new IllegalArgumentException("Com sa�de");
		}
		if (saude2.equalsIgnoreCase("n�o")) {
			throw new IllegalArgumentException("Sem sa�de");
		}
		this.saude = saude2;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		if (idade < 0) {
			throw new IllegalArgumentException("Idade inv�lida. Digite novamente.");

		}

		this.idade = idade;
	}

	@Override
	public String toString() {
		return "Tamagushi [nome=" + nome + ", fome=" + fome + ", saude=" + saude + ", idade=" + idade + "]";
	}

}
