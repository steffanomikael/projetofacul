package br.aeso.exercicio01;

public class AnalistaDeSistemas extends Funcionario {

	public AnalistaDeSistemas(String nome, double salario) {
		super(nome, salario);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Dados do analista de sistemas:\n");
		builder.append("Nome: " + super.getNome() + "\n");
		builder.append("Sal�rio: R$ " + String.format("%.2f", super.getSalario()) + "\n");

		return builder.toString();
	}
}
