package br.aeso.exercicio01;

import java.util.Scanner;

public class Application {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		Funcionario funcionario1 = new Gerente("Bill gates", 200000);
		Funcionario funcionario2 = new Programador("Jo�o Andrade", 15000);
		Funcionario funcionario3 = new AnalistaDeSistemas("Mark Zuckberg", 20000);

		while (true) {
			System.out.println("SEJA BEM VINDO AO SISTEMA");
			System.out.println("1 - Imprimir dados");
			System.out.println("2 - Aumentar sal�rio");
			System.out.println("9 - Sair do programa");
			int escolha = teclado.nextInt();
			char opcao = ' ';

			if (escolha == 1) {
				System.out.print(
						"Deseja imprimir os dados do gerente(G), do programador(P) ou do Analista de sistemas(A)? ");
				opcao = teclado.next().charAt(0);
				if (opcao == 'g' || opcao == 'G') {
					System.out.println(funcionario1);

				} else if (opcao == 'p' || opcao == 'P') {
					System.out.println(funcionario2);

				} else {
					System.out.println(funcionario3);

				}

			} else if (escolha == 2) {
				System.out.print(
						"Deseja aumentar o salario do gerente(G), do programador(P) ou do Analista de sistemas(A)? ");
				opcao = teclado.next().charAt(0);
				if (opcao == 'g' || opcao == 'G') {
					funcionario1.aumentarSalario();

				} else if (opcao == 'p' || opcao == 'P') {
					funcionario2.aumentarSalario();

				} else {
					funcionario3.aumentarSalario();
				}

			} else if (escolha == 9) {
				System.out.println("Programa finalizado...");

				break;
			}
		}

		teclado.close();
	}
}
