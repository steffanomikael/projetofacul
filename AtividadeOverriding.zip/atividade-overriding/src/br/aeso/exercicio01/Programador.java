package br.aeso.exercicio01;

public class Programador extends Funcionario {

	public Programador(String nome, double salario) {
		super(nome, salario);
	}

	@Override
	public void aumentarSalario() {
		super.setSalario(super.getSalario() * 1.20);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Dados do Programador:\n");
		builder.append("Nome: " + super.getNome() + "\n");
		builder.append("Sal�rio: R$ " + String.format("%.2f", super.getSalario()) + "\n");

		return builder.toString();
	}
}
