package br.aeso.exercicio03;

public class Cliente {
	private String nome;
	private double salarioMensal;

	public Cliente(String nome, double salarioMensal) {
		this.setNome(nome);
		this.setSalarioMensal(salarioMensal);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getSalarioMensal() {
		return salarioMensal;
	}

	public void setSalarioMensal(double salarioMensal) {
		this.salarioMensal = salarioMensal;
	}

	@Override
	public String toString() {
		return "Cliente [nome=" + nome + ", salarioMensal=" + salarioMensal + "]";
	}

}
