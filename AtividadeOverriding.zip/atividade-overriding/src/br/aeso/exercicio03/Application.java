package br.aeso.exercicio03;

public class Application {
	public static void main(String[] args) {
		Cliente cliente = new Cliente("Jo�o Andrade", 15000);
		Conta conta1 = new Conta(cliente, "222-331", 100, 15000);
		Conta conta2 = new ContaEspecial(cliente, "222-33", 100, 45000);

		conta1.depositar(50000);
		conta2.depositar(50000);

		System.out.println(conta1);
		System.out.println(conta2);

		conta1.sacar(15000);
		conta2.sacar(45000);

		System.out.println("-------------------------------");
		System.out.println(conta1);
		System.out.println(conta2);

	}
}
