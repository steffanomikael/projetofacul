package br.aeso.exercicio03;

public class ContaEspecial extends Conta {

	protected ContaEspecial(Cliente cliente, String numeroConta, double saldo, double limite) {
		super(cliente, numeroConta, saldo);
		this.setLimite(limite);
	}

	@Override
	public void setLimite(double limite) {
		if (limite > (super.getCliente().getSalarioMensal() * 3)) {
			throw new IllegalArgumentException("O limite n�o pode ser maior que o sal�rio mensal do cliente!");
		}

		super.limite = limite;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Informa��es da Conta Especial\n");
		builder.append("Cliente: " + super.getCliente() + "\n");
		builder.append("Saldo: R$" + String.format("%.2f", super.getSaldo()) + "\n");
		builder.append("Limite de R$" + String.format("%.2f", super.limite) + "\n");

		return builder.toString();
	}

}
