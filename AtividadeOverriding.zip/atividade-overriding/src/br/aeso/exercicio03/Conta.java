package br.aeso.exercicio03;

public class Conta {
	private Cliente cliente;
	private String numeroConta;
	private double saldo;
	protected double limite;

	public Conta(Cliente cliente, String numeroConta, double saldo, double limite) {
		this.setCliente(cliente);
		this.setNumeroConta(numeroConta);
		this.setSaldo(saldo);
		this.setLimite(limite);
	}

	protected Conta(Cliente cliente, String numeroConta, double saldo) {
		this.setCliente(cliente);
		this.setNumeroConta(numeroConta);
		this.setSaldo(saldo);
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public String getNumeroConta() {
		return numeroConta;
	}

	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public double getLimite() {
		return limite;
	}

	public void setLimite(double limite) {
		if (limite > this.getCliente().getSalarioMensal()) {
			throw new IllegalArgumentException("O limite n�o pode ser maior que o sal�rio mensal do cliente!");
		}

		this.limite = limite;
	}

	public void depositar(double valorDeposito) {
		if (valorDeposito < 0) {
			throw new IllegalArgumentException("O valor do deposito n�o pode ser negativo!");
		}

		this.setSaldo(this.getSaldo() + valorDeposito);
	}

	public boolean sacar(double valorSaque) {
		if (valorSaque > this.getLimite()) {
			return false;
		} else {
			this.setSaldo(this.getSaldo() - valorSaque);

			return true;
		}
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Informa��es da conta\n");
		builder.append("Cliente: " + cliente + "\n");
		builder.append("Saldo: R$" + String.format("%.2f", saldo) + "\n");
		builder.append("Limite de R$" + String.format("%.2f", limite) + "\n");

		return builder.toString();
	}

}
