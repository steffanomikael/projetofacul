package br.aeso.exercicio02;

public abstract class InfoCliente {

	public abstract String getInfo();
}
