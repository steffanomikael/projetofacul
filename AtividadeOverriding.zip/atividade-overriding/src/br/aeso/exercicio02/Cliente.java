package br.aeso.exercicio02;

public class Cliente {

	private String nome;
	private String endereco;
	private InfoCliente infoCliente;

	public Cliente(String nome, String endereco, InfoCliente infoCliente) {
		this.setNome(nome);
		this.setEndereco(endereco);
		this.setInfoCliente(infoCliente);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public InfoCliente getInfoCliente() {
		return infoCliente;
	}

	public void setInfoCliente(InfoCliente infoCliente) {
		this.infoCliente = infoCliente;
	}

}
