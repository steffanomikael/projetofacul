package br.aeso.exercicio02;

public class Application {
	public static void main(String[] args) {
		ClienteFidelizacao cliente1 = new ClienteFidelizacao("Jo�o Andrade", "Miami",
				new InfoClientePessoaFisica("931.846.850-47"), 50, "05/04/2020");

		ClienteFidelizacao cliente2 = new ClienteFidelizacaoEspecial("Microsoft", "Las vegas", new InfoClientePessoaJuridica("06.340.050/0001-02"), 50, "05/04/2020");
		
		System.out.println(cliente1.getBonus());
		System.out.println(cliente2.getBonus());
		
		cliente1.adicionaBonus(2000);
		cliente2.adicionaBonus(2000);
		
		System.out.println(cliente1.getBonus());
		System.out.println(cliente2.getBonus());
	}
}
