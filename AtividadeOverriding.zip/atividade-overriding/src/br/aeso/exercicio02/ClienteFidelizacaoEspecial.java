package br.aeso.exercicio02;

public class ClienteFidelizacaoEspecial extends ClienteFidelizacao {

	public ClienteFidelizacaoEspecial(String nome, String endereco, InfoCliente infoCliente, double bonus,
			String validade) {
		super(nome, endereco, infoCliente, bonus, validade);
	}

	@Override
	public void adicionaBonus(double valorDaCompra) {
		this.setBonus(this.getBonus() + (valorDaCompra * 0.10));
	}

}
