package br.aeso.exercicio02;

public class ClienteFidelizacao extends Cliente {
	private double bonus;
	private String validade;

	public ClienteFidelizacao(String nome, String endereco, InfoCliente infoCliente, double bonus, String validade) {
		super(nome, endereco, infoCliente);
		this.setBonus(bonus);
		this.setValidade(validade);
	}

	public double getBonus() {
		return bonus;
	}

	public void setBonus(double bonus) {
		this.bonus = bonus;
	}

	public String getValidade() {
		return validade;
	}

	public void setValidade(String validade) {
		this.validade = validade;
	}

	public void adicionaBonus(double valorDaCompra) {
		this.setBonus(this.getBonus() + (valorDaCompra * 0.05));
	}

}
