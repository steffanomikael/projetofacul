package br.aeso.exercicio02;

public class InfoClientePessoaFisica extends InfoCliente {
	private String cpf;

	public InfoClientePessoaFisica(String cpf) {
		this.setCpf(cpf);
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	@Override
	public String getInfo() {
		return getCpf();
	}

}
