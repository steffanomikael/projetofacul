package prova;

public class Programa {

	private static void imprimir(int[] vetor) {
		int[] Array = vetor;
		ordenandoCrescente(Array);

		for (int i = 0; i < vetor.length; i++) {
			System.out.println(vetor[i]);
		}
	}

	public static void main(String[] args) {

		int[] vetor = { 7, 6, 3, 2, 8, 1 };
		imprimir(vetor);
	}

	private static void ordenandoCrescente(int[] vetor) {
		for (int i = 0; i < vetor.length; i++) {
			for (int j = 0; j < vetor.length - 1; j++) {
				if (vetor[j] > vetor[j + 1]) {
					int var = vetor[j];
					vetor[j] = vetor[j + 1];
					vetor[j + 1] = var;
				}
			}
		}
	}
}

