package services;

public class No<T extends Object> {
	private T dado;
	private No<T> proximo;

	private int tamanho;

	public No(T dado) {
		this.dado = dado;
		proximo = null;
	}

	public void inserir(T dado) {
		if (this.proximo == null) {
			this.proximo = new No<T>(dado);
		} else {
			this.proximo.inserir(dado);
		}
	}

	public void remover() {
		if (this.proximo != null) {
			this.dado = this.proximo.dado;
			this.proximo = this.proximo.proximo != null ? this.proximo.proximo : null;
		} else {
			this.dado = null;
			this.proximo = null;
		}
	}

	public No<T> getUltimo() {
		if (this.proximo == null) {
			return this;
		} else {
			return this.proximo.getUltimo();
		}
	}

	public T consultar() {
		return this.dado;
	}

	private void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}

	public int getTamanho() {
		this.tamanho++;
		if (this.proximo == null) {
			return this.tamanho;
		} else {
			this.proximo.setTamanho(tamanho);
			return this.proximo.getTamanho();
		}

	}
}
