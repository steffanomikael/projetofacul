package services;

public class FilaDinamica<T extends Object> {
	private No<T> inicio;
	private No<T> fim;

	public void inserir(T dado) {
		if (isEmpty()) {
			this.inicio = new No<T>(dado);
			this.fim = this.inicio;
		} else {
			this.inicio.inserir(dado);
			this.fim = inicio.getUltimo();
		}

	}

	public void remover() {
		if (isEmpty()) {
			throw new IllegalArgumentException("A fila est� vazia!");
		}

		this.inicio.remover();
		this.fim = this.inicio.getUltimo();
	}

	public T consultar() {
		if (isEmpty()) {
			throw new IllegalArgumentException("A fila est� vazia!");
		}

		return this.inicio.consultar();
	}

	public int tamanho() {
		if (isEmpty()) {
			throw new IllegalArgumentException("A fila estar vazia!");
		}
		return this.inicio.getTamanho();
	}

	public boolean isEmpty() {
		return this.inicio == null && this.fim == null ? true : false;
	}

	public boolean isFull() {
		return false;
	}

}
