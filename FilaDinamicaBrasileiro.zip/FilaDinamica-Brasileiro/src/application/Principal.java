package application;

import services.FilaDinamica;

public class Principal {

	public static void main(String[] args) {
		FilaDinamica<String> fila = new FilaDinamica<String>();
		fila.inserir("St�ffano");
		fila.inserir("Maria");
		fila.inserir("Lucas");
		fila.inserir("Rafael");
		fila.inserir("Lucian");
		fila.remover();
		fila.remover();
		System.out.println("Come�o da fila �: " + fila.consultar());
		System.out.println("O tamanho da fila �: " + fila.tamanho());
	}

}
