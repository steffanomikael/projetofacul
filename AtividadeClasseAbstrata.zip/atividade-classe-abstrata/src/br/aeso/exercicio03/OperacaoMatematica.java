package br.aeso.exercicio03;

public abstract class OperacaoMatematica {
	public abstract double calcula(double n1, double n2);
}
