package br.aeso.exercicio03;

public class Subtracao extends OperacaoMatematica {

	@Override
	public double calcula(double numero1, double numero2) {
		return numero1 - numero2;
	}

}
