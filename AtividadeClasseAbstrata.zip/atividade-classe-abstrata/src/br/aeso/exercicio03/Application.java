package br.aeso.exercicio03;

import java.util.Scanner;

public class Application {
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		OperacaoMatematica operacaoMatematica = null;

		System.out.println("1 - Soma");
		System.out.println("2 - Subtra��o");
		System.out.println("3 - Multiplica��o");
		System.out.println("4 - Divis�o");
		System.out.print("Escolha um n�mero: ");
		int escolha = scan.nextInt();
		String operacao = "";

		if (escolha == 1) {
			operacao = "soma";
			operacaoMatematica = new Soma();
		} else if (escolha == 2) {
			operacao = "subtra��o";
			operacaoMatematica = new Subtracao();
		} else if (escolha == 3) {
			operacao = "mutiplica��o";
			operacaoMatematica = new Multiplicacao();
		} else if (escolha == 4) {
			operacao = "divis�o";
			operacaoMatematica = new Divisao();
		}

		if (operacaoMatematica != null) {
			System.out.print("Digite um n�mero: ");
			double numero1 = scan.nextDouble();
			System.out.print("Digite outro n�mero: ");
			double numero2 = scan.nextDouble();
			double resultado = operacaoMatematica.calcula(numero1, numero2);
			System.out.print(
					"O resultado da " + operacao + " entre " + numero1 + " e " + numero2 + " � igual a: " + resultado);
		}

		scan.close();
	}
}
