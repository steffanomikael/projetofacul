package br.aeso.exercicio03;

public class Multiplicacao extends OperacaoMatematica {

	@Override
	public double calcula(double n1, double n2) {
		return n1 * n2;
	}

}
