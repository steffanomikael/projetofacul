package br.aeso.exercicio02;

public class Quadrado extends FormaGeometrica {

	private double lado;

	public Quadrado(double lado) {
		this.setLado(lado);
	}

	public double getLado() {
		return lado;
	}

	public void setLado(double lado) {
		this.lado = lado;
	}

	@Override
	public double area() {
		return Math.pow(lado, 2);
	}

	@Override
	public double comprimento() {
		return lado * 4;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Informa��es sobre o Quadrado:");
		builder.append("O lado do quadrado � " + lado);
		builder.append("O calculo da area �: " + area());
		builder.append("O calculo do comprimento �: " + comprimento());

		return builder.toString();
	}

}
