package br.aeso.exercicio02;

import java.util.Scanner;

public class Application {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		FormaGeometrica formaGeometrica = null;

		System.out.print("Circulo ou Quadrado? ");
		String escolher = scan.next();

		if (escolher == "Circulo") {
			System.out.print("Raio: ");
			double raio = scan.nextDouble();

			formaGeometrica = new Circulo(raio);
		} else {
			System.out.print("Lado: ");
			double lado = scan.nextDouble();

			formaGeometrica = new Quadrado(lado);
		}

		System.out.println(formaGeometrica);

		scan.close();
	}
}
