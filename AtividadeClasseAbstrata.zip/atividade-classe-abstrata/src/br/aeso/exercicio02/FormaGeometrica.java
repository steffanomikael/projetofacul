package br.aeso.exercicio02;

public abstract class FormaGeometrica {

	public abstract double area();

	public abstract double comprimento();
}
