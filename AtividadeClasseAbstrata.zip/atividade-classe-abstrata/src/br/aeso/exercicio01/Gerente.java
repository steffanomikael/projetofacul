package br.aeso.exercicio01;

public class Gerente extends Funcionario {

	public Gerente(String nome, double salario) {
		super(nome, salario);
	}

	@Override
	public void aumentarSalario() {
		super.setSalario(super.getSalario() * 1.10);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Dados do Gerente: ");
		builder.append("Nome: " + super.getNome() + "\n");
		builder.append("Sal�rio: R$ " + String.format("%.2f", super.getSalario()) + "\n");

		return builder.toString();
	}

}
