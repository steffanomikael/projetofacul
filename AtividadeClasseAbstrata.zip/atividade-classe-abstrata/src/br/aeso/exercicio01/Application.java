package br.aeso.exercicio01;

import java.util.Scanner;

public class Application {
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		Funcionario funcionario1 = new Gerente("St�ffano Mikael", 3560);
		Funcionario funcionario2 = new Programador("Ana Paula", 420);

		while (true) {
			System.out.println("1 - Imprimir dados");
			System.out.println("2 - Aumentar sal�rio");

			int escolha = scan.nextInt();
			int escolhendo = 0;

			if (escolha == 1) {
				System.out.println("Para os dados do gerente digite 1: ");
				System.out.println("Para os dados do programador digite 2: ");
				escolhendo = scan.nextInt();
				System.out.println();

				if (escolhendo == 1) {
					System.out.println(funcionario1);

				} else {
					System.out.println(funcionario2);

				}

			} else if (escolha == 2) {
				System.out.println("Para aumentar o sal�rio do gerente digite 1: ");
				System.out.print("Para aumentar o sal�rio do programador digite 2: ");
				escolhendo = scan.nextInt();
				if (escolhendo == 1) {
					funcionario1.aumentarSalario();

				} else {
					funcionario2.aumentarSalario();

				}
				break;
			}
		}

		scan.close();
	}
}
