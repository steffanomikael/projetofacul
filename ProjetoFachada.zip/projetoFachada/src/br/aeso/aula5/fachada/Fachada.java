package br.aeso.aula5.fachada;

import java.util.List;

import br.aeso.aula5.cliente.Cliente;
import br.aeso.aula5.cliente.ControladorCliente;

public class Fachada {

	private ControladorCliente controladorCliente;
	private static Fachada instance;

	private Fachada() {
	}

	public static Fachada getInstance() {
		if (instance == null) {
			instance = new Fachada();
		}

		return instance;
	}

	public void cadastrarCliente(Cliente cliente) {

		controladorCliente = new ControladorCliente();
		controladorCliente.cadastrar(cliente);
	}

	public void atualizarCliente(Cliente cliente) {

	}

	public Boolean removerCliente(String codigo) {
		return false;
	}

	public Cliente procurarCliente(String codigo) {
		return null;
	}

	public List<Cliente> listarCliente() {
		return null;
	}

}
