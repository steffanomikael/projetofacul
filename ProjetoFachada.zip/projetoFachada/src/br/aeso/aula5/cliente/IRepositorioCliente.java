package br.aeso.aula5.cliente;

import java.util.List;

public interface IRepositorioCliente {
	public void cadastrar(Cliente cliente);

	public void atualizar(Cliente cliente);

	public boolean remover(String codigo);

	public Cliente procurar(String codigo);

	public boolean existe(String codigo);

	public List<Cliente> listar();
}