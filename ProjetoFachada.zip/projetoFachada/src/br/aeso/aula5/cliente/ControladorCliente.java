package br.aeso.aula5.cliente;

import java.util.List;

public class ControladorCliente {

	public void cadastrar(Cliente cliente) {
	}

	public void atualizar(Cliente cliente) {

	}

	public boolean remover(String codigo) {
		return false;
	}

	public Cliente procurar(String codigo) {
		return null;
	}

	public List<Cliente> listar() {
		return null;
	}
}
