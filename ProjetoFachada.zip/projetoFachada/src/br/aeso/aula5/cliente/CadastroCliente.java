package br.aeso.aula5.cliente;

import java.text.ParseException;

public class CadastroCliente {

	public static void main(String[] args) throws ParseException {

		System.out.println("INFORMA��ES");
		
		Cliente cliente = new Cliente("123", "St�ffano Mikael", "125.789.321-08");
		
		Fachada fachada = Fachada.getInstance();
		fachada.cadastrarCliente(cliente);
	}

}
