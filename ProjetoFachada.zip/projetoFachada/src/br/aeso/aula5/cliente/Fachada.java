package br.aeso.aula5.cliente;

public class Fachada {

		private ControladorCliente controladorCliente;
		private static Fachada instance;

		private Fachada() {
		}

		public static Fachada getInstance() {
			if (instance == null) {
				instance = new Fachada();
			}

			return instance;
		}

		public void cadastrarCliente(Cliente cliente) {
			
		}
}
