package br.aeso.aula5.cliente;

import java.util.List;

public class RepositorioVetorCliente implements IRepositorioCliente {

	@Override
	public void cadastrar(Cliente cliente) {
	}

	@Override
	public void atualizar(Cliente cliente) {

	}

	@Override
	public boolean remover(String codigo) {
		return false;
	}

	@Override
	public Cliente procurar(String codigo) {
		return null;
	}

	@Override
	public boolean existe(String codigo) {
		return false;
	}

	@Override
	public List<Cliente> listar() {
		return null;
	}

}
