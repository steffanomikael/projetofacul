package br.aeso.aula05.cliente;

import java.util.List;

public class RepositorioClienteArray implements IRepositorioCliente {

	@Override
	public void cadastrar(Cliente cliente) {
		// System.out.println(cliente);
	}

	@Override
	public void atualizar(Cliente cliente) {

	}

	@Override
	public boolean remover(String codigo) {
		return false;
	}

	@Override
	public Cliente procurar(String codigo) {
		return null;
	}

	@Override
	public boolean existe(String codigo) {
		return false;
	}

	@Override
	public List<Cliente> listar() {
		return null;
	}

}
