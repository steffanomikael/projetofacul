package br.aeso.aula05.cliente;

import java.text.ParseException;

import javax.swing.text.MaskFormatter;

import br.aeso.aula05.util.ValidarCpf;

public class Cliente {
	private String codigo;
	private String nome;
	private String cpf;

	public Cliente(String codigo, String nome, String cpf) {
		this.setCodigo(codigo);
		this.setNome(nome);
		this.setCpf(cpf);
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = ValidarCpf.validar(cpf);
	}

	public String getCpfFormatado() throws ParseException {
		MaskFormatter formatter = new MaskFormatter("###.###.###-##");
		formatter.setValueContainsLiteralCharacters(false);
		return formatter.valueToString(this.getCpf());
	}

	@Override
	public String toString() {
		return "Cliente [codigo=" + codigo + ", nome=" + nome + ", cpf=" + cpf + "]";
	}

}
