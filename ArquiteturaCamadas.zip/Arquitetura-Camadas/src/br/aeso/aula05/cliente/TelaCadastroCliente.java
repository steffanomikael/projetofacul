package br.aeso.aula05.cliente;

import java.text.ParseException;

import br.aeso.aula05.fachada.Fachada;

public class TelaCadastroCliente {
	public static void main(String[] args) throws ParseException {
		Cliente cliente = new Cliente("1", "Jo�o Andrade", "334.686.960-19");
		Fachada fachada = Fachada.getInstance();

		fachada.cadastrarCliente(cliente);
	}
}
