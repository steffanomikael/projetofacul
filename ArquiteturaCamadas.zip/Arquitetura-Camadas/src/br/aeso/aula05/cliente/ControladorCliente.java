package br.aeso.aula05.cliente;

import java.util.List;

public class ControladorCliente {
	private IRepositorioCliente repositorio;

	public void cadastrar(Cliente cliente) {
		//System.out.println(cliente);
		repositorio = new RepositorioClienteArray();
		repositorio.cadastrar(cliente);
	}

	public void atualizar(Cliente cliente) {

	}

	public boolean remover(String codigo) {
		return false;
	}

	public Cliente procurar(String codigo) {
		return null;
	}

	public List<Cliente> listar() {
		return null;
	}
}
