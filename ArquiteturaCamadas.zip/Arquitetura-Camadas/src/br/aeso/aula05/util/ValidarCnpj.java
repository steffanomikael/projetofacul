package br.aeso.aula05.util;

public class ValidarCnpj {

	private ValidarCnpj() {
	}

	public static String validar(String cnpj) {
		cnpj = cnpj.replaceAll("[.-/]", "");

		if (cnpj.length() != 14) {
			throw new IllegalArgumentException("Cnpj invalido!");
		}

		return cnpj;
	}

}
