package br.aeso.aula05.util;

public class ValidarCpf {

	private ValidarCpf() {
	}

	public static String validar(String cpf) {
		cpf = cpf.replaceAll("[.-]", "");

		if (cpf.length() != 11) {
			throw new IllegalArgumentException("Cpf invalido!");
		}

		return cpf;
	}

}
