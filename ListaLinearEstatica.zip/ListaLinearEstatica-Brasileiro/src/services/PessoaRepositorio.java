package services;

import entities.Pessoa;
import exceptions.ObjetoJaExistenteException;
import exceptions.ObjetoNaoExistenteException;

public class PessoaRepositorio implements IListaEstatica {
	private static final int MAX_LIST = 100;
	private Pessoa[] pessoas = new Pessoa[MAX_LIST];
	private int tamanhoLista = 0;

	@Override
	public void inserir(Object object) throws ObjetoJaExistenteException {
		int indice = localizarIndice(object);
		if (indice != -1) {
			throw new ObjetoJaExistenteException("O objeto existe!");
		}

		if (tamanhoLista == pessoas.length) {
			throw new RuntimeException("A lista est� cheia!");
		}

		for (int i = 0; i < pessoas.length; i++) {
			if (pessoas[i] == null) {
				pessoas[i] = (Pessoa) object;
				aumentarTamanho();
				break;
			}
		}

	}

	@Override
	public void remover(Object object) throws ObjetoNaoExistenteException {
		int i = localizarIndice(object);

		if (i == -1) {
			throw new ObjetoNaoExistenteException("O objeto n�o existe");
		}

		pessoas[i] = null;
		diminuirTamanho();
		Pessoa[] temp = new Pessoa[MAX_LIST];
		int tamanhoTemp = 0;
		for (int j = 0; j < pessoas.length; j++) {
			if (pessoas[j] != null) {
				temp[tamanhoTemp++] = pessoas[j];
			}
		}

		for (int j = 0; j < pessoas.length; j++) {
			if (pessoas[j] != null) {
				pessoas[j] = null;
			}
		}

		for (int j = 0; j < temp.length; j++) {
			if (temp[j] != null) {
				pessoas[j] = temp[j];
			}
		}

	}

	@Override
	public int localizarIndice(Object object) {
		Pessoa pessoa = (Pessoa) object;

		for (int i = 0; i < pessoas.length; i++) {
			if (pessoas[i] != null && pessoas[i].equals(pessoa)) {
				return i;
			}
		}

		return -1;
	}

	@Override
	public Object pesquisarPorValor(Object object) throws ObjetoNaoExistenteException {
		int i = localizarIndice(object);

		if (i == -1) {
			throw new ObjetoNaoExistenteException("O objeto n�o existe!");
		}

		return pessoas[i];
	}

	@Override
	public void alterar(Object object) throws ObjetoNaoExistenteException {
		int i = localizarIndice(object);
		if (i == -1) {
			throw new ObjetoNaoExistenteException("O objeto n�o existe!");
		}

		pessoas[i] = (Pessoa) object;
	}

	public void imprimir() {
		for (int i = 0; i < pessoas.length; i++) {
			if (pessoas[i] != null)
				System.out.println(pessoas[i]);

		}
	}

	private void aumentarTamanho() {
		tamanhoLista++;
	}

	private void diminuirTamanho() {
		tamanhoLista--;
	}
}
