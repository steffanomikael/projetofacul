package application;

import entities.Pessoa;
import services.PessoaRepositorio;

public class Principal {
	public static void main(String[] args) {
		try {
			PessoaRepositorio pessoaRepositorio = new PessoaRepositorio();
			pessoaRepositorio.inserir(new Pessoa("Lucas", "129.894.000-03"));
			pessoaRepositorio.inserir(new Pessoa("Momo", "892.562.000-01"));
			pessoaRepositorio.inserir(new Pessoa("Dayh", "362.536.389-06"));
			pessoaRepositorio.inserir(new Pessoa("St�ffano", "569.832.000-09"));
			pessoaRepositorio.remover(new Pessoa("Jeongch", "189.556.340-06"));

			pessoaRepositorio.imprimir();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
