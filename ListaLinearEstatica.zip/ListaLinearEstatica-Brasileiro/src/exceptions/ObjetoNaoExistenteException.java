package exceptions;

public class ObjetoNaoExistenteException extends Exception {

	private static final long serialVersionUID = 1L;

	public ObjetoNaoExistenteException(String mensagemError) {
		super(mensagemError);
	}

}
