package services;

public class ListaInt {
	private Integer dado;
	private ListaInt proximo;

	public ListaInt(int dado) {
		this.dado = dado;
	}

	public void inserir(int dado) {
		if (this.proximo == null) {
			this.proximo = new ListaInt(dado);
		} else {
			this.proximo.inserir(dado);
		}
	}

	public void remover(int dado) {
		if (this.dado == dado) {
			if (this.proximo != null) {
				this.dado = this.proximo.dado;
				this.proximo = this.proximo.proximo != null ? this.proximo.proximo : null;
			} else {
				this.dado = null;
				this.proximo = null;
			}
		} else if (this.proximo != null) {
			this.proximo.remover(dado);
		} else {
			throw new RuntimeException("Objeto n�o existente!");
		}
	}

	public void imprimir() {
		System.out.println(dado != null ? dado : "");

		if (this.proximo != null) {
			this.proximo.imprimir();
		}
	}

}
