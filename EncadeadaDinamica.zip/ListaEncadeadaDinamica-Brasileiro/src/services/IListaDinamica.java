package services;

public interface IListaDinamica<T extends Object> {
	public void inserir(T dado);

	public void remover(T dado);

	public void imprimir();
}
