package services;

public class ListaGenerica<T extends Object> implements IListaDinamica<T> {

	private T dado;
	private ListaGenerica<T> proximo;

	public ListaGenerica(T dado) {
		this.dado = dado;
	}

	@Override
	public void inserir(T dado) {
		if (this.proximo == null) {
			this.proximo = new ListaGenerica<T>(dado);
		} else {
			this.proximo.inserir(dado);
		}
	}

	@Override
	public void remover(T dado) {
		if (this.dado.equals(dado) || this.dado == dado) {
			if (this.proximo != null) {
				this.dado = this.proximo.dado;
				this.proximo = this.proximo.proximo != null ? this.proximo.proximo : null;
			} else {
				this.dado = null;
				this.proximo = null;
			}
		} else if (this.proximo != null) {
			this.proximo.remover(dado);
		} else {
			throw new RuntimeException("Objeto n�o existente!");
		}
	}

	@Override
	public void imprimir() {
		System.out.println(dado != null ? dado : "");

		if (this.proximo != null) {
			this.proximo.imprimir();
		}
	}

}
