package application;

import services.IListaDinamica;
import services.ListaGenerica;
import services.ListaInt;

public class Principal {
	public static void main(String[] args) {
		
		ListaInt listaInt = new ListaInt(2);
		listaInt.inserir(2);
		listaInt.inserir(6);
		listaInt.inserir(1);
		listaInt.imprimir();
		

		
		IListaDinamica<String> lista = new ListaGenerica<String>("St�ffano");
		lista.inserir("Lucas");
		lista.inserir("Momo");
		lista.remover("Jihyo");
		lista.imprimir();
		

	}

}
