package enuns;

public enum Funcao {
	LIMPEZA;

}
