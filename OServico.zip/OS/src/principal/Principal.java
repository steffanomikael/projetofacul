package principal;

import java.util.Date;
import java.util.Scanner;

import aeso.Cliente;
import aeso.Fornecedor;
import aeso.Funcao;
import aeso.Funcionario;
import aeso.OrdemDeServico;
import aeso.Produto;
import aeso.RepositorioOS;
import aeso.TProduto;

public class Principal {
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		RepositorioOS repositorioOS = new RepositorioOS();

		while (true) {
			System.out.println("Digite o n�mero desejado");
			System.out.println("1 - inserir ordem de servi�o");
			System.out.println("4 - imprimir ordem de servi�o");
			System.out.println("5 - Escolha ordem de servi�o");
			System.out.println("7 - quantidade ordem de servi�o");
			System.out.println("9 - Sair");
			int operacao = scan.nextInt();

			if (operacao == 1) {
				OrdemDeServico ordem = new OrdemDeServico();
				ordem.setNumero(123);
				ordem.setDescricao("Minha descricao");
				ordem.setValor(520);
				ordem.setDateInicio(new Date());
				ordem.setDataFim(new Date());

				Cliente cli = new Cliente();
				cli.setNome("Lucas Moura");
				cli.setCpf("152.568.002.75");
				cli.setIdade(23);
				ordem.setCliente(cli);
				System.out.println();

				// chamando ordem

				Funcionario fun = new Funcionario();
				fun.setNome("Ana Paula");
				fun.setMatricula("3151636");
				fun.setIdade(18);
				fun.setFuncao(Funcao.PINTOR);
				ordem.setFuncionario(fun);
				System.out.println();

				Fornecedor f = new Fornecedor();
				f.setNome("Rafael Fernando");
				f.setCnpj("37.789.542/0021-30");
				f.setRazaoSocial("Amortex");
				f.setFuncao(Funcao.MECANICO);
				ordem.setFornecedor(f);
				System.out.println();

				Produto[] caixa = new Produto[3];

				Produto p1 = new Produto();
				p1.setCodigo("00021");
				p1.setMarca("FINISH");
				p1.setValor(18);
				p1.setModelo("033581");
				p1.settProduto(TProduto.LIMPEZA);
				System.out.println();

				Produto p2 = new Produto();
				p2.setCodigo("00521");
				p2.setMarca("Kalim");
				p2.setValor(17);
				p2.setModelo("025421");
				p2.settProduto(TProduto.LIMPEZA);
				System.out.println();

				Produto p3 = new Produto();
				p3.setCodigo("00654");
				p3.setMarca("Limper");
				p3.setValor(20);
				p3.setModelo("05698");
				p3.settProduto(TProduto.LIMPEZA);
				System.out.println();

				caixa[0] = p1;
				caixa[1] = p2;
				caixa[2] = p3;
				ordem.setListaProdutos(caixa);

				repositorioOS.salvar(ordem);

			} else if (operacao == 4) {
				repositorioOS.imprimir();
			} else if (operacao == 7) {
				System.out.println("Quantidade de ordem de servi�o armazenada: " + repositorioOS.quantidadeOrdem());
			} else if (operacao == 9) {
				System.out.println("Programa encerrado.");
				System.out.println("----------------------------");
				break;
			} else if (operacao == 5) {
				repositorioOS.mostrarDisponivel();
				System.out.println();
				System.out.println("Informe o numero da ordem de servi�o: ");
				int numero = scan.nextInt();
				repositorioOS.buscarOrdem(numero);

			}
		}
	}
}
