package aeso;

public class Produto {

	private String marca;
	private String modelo;
	private double valor;
	private String codigo;
	private TProduto tProduto;

	public Produto() {

	}

	public Produto(String marca, String modelo, double valor, String codigo, TProduto tProduto) {
		super();
		this.marca = marca;
		this.modelo = modelo;
		this.valor = valor;
		this.codigo = codigo;
		this.tProduto = tProduto;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;

	}

	public TProduto gettProduto() {
		return tProduto;
	}

	public void settProduto(TProduto tProduto) {
		this.tProduto = tProduto;
	}
}
