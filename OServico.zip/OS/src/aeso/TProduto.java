package aeso;

public enum TProduto {

	LIMPEZA, PE�AS;
}
