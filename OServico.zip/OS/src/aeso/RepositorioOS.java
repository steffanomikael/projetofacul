package aeso;

public class RepositorioOS {

	private OrdemDeServico[] lista = new OrdemDeServico[10];

	public void salvar(OrdemDeServico ordem) {
		for (int i = 0; i < this.lista.length; i++) {
			if (this.lista[i] == null) {
				this.lista[i] = ordem;
				break;
			}

		}
	}

	public int quantidadeOrdem() {
		int numeroDeOrdem = 0;

		for (OrdemDeServico ordem : lista) {
			if (ordem != null) {
				numeroDeOrdem++;
			}
		}
		return numeroDeOrdem;
	}

	public void mostrarDisponivel() {
		System.out.println();
		System.out.println("Ordens disponiveis: ");
		if (lista[0] != null) {
			System.out.println(0);
			for (int i = 1; i < lista.length; i++) {
				if (lista[i] != null) {
					System.out.println(i);
				}
			}
		}
	}

	public void buscarOrdem(int n) {
		if (n > lista.length && n < 0) {
			System.out.println("Ordem de servi�o inexistente");
		} else {
			if (lista[n] != null) {
				imprimirEspecifico(n);
			} else {
				System.out.println("Ordem de servi�o inexistente");
			}
		}
	}

	public void imprimirEspecifico(int n) {
		OrdemDeServico ordem = lista[n];
		System.out.println("------------------");
		System.out.println("Numero: " + ordem.getNumero());
		System.out.println("Descri��o: " + ordem.getDescricao());
		System.out.println("Data inicio: " + ordem.getDateInicio());
		System.out.println("Data Fim: " + ordem.getDataFim());
		System.out.println("Valor: " + ordem.getValor());

		System.out.println();
		System.out.println("CLIENTE");
		System.out.println("Nome: " + ordem.getCliente().getNome());
		System.out.println("CPF: " + ordem.getCliente().getCpf());
		System.out.println("Idade: " + ordem.getCliente().getIdade());

		System.out.println();
		System.out.println("FUNCIONARIO");
		System.out.println("Nome: " + ordem.getFuncionario().getNome());
		System.out.println("Matricula: " + ordem.getFuncionario().getMatricula());
		System.out.println("Idade: " + ordem.getFuncionario().getIdade());
		System.out.println("Fun��o: " + ordem.getFuncionario().getFuncao());

		System.out.println();
		System.out.println("FORNECEDOR");
		System.out.println("Nome: " + ordem.getFornecedor().getNome());
		System.out.println("Raz�o social: " + ordem.getFornecedor().getRazaoSocial());
		System.out.println("CNPJ: " + ordem.getFornecedor().getCnpj());

		System.out.println();
		System.out.println("LISTA DE PRODUTOS");
		for (Produto p : ordem.getListaProdutos()) {
			System.out.println("Marca: " + p.getMarca());
			System.out.println("Modelo: " + p.getModelo());
			System.out.println("Valor: R$ " + p.getValor());
			System.out.println("Codigo: " + p.getCodigo());
			System.out.println("Tipo Produto: " + p.gettProduto());
			System.out.println();
		}

		System.out.println("----------------------");
	}

	public void imprimir() {
		for (OrdemDeServico ordem : this.lista) {
			if (ordem != null) {
				System.out.println("-----------------------");
				System.out.println("Numero: " + ordem.getNumero());
				System.out.println("Descri��o: " + ordem.getDescricao());
				System.out.println("Data inicio: " + ordem.getDateInicio());
				System.out.println("Data fim: " + ordem.getDataFim());
				System.out.println("Valor: " + ordem.getValor());

				System.out.println();
				System.out.println("CLIENTE");
				System.out.println("Nome: " + ordem.getCliente().getNome());
				System.out.println("CPF: " + ordem.getCliente().getCpf());
				System.out.println("Idade: " + ordem.getCliente().getIdade());

				System.out.println();
				System.out.println("FUNCIONARIO");
				System.out.println("Nome: " + ordem.getFuncionario().getNome());
				System.out.println("Matricula: " + ordem.getFuncionario().getMatricula());
				System.out.println("Idade: " + ordem.getFuncionario().getIdade());
				System.out.println("Fun��o: " + ordem.getFuncionario().getFuncao());

				System.out.println();
				System.out.println("FORNECEDOR");
				System.out.println("Nome: " + ordem.getFornecedor().getNome());
				System.out.println("Raz�o social: " + ordem.getFornecedor().getRazaoSocial());
				System.out.println("CNPJ: " + ordem.getFornecedor().getCnpj());

				System.out.println();
				System.out.println("LISTA DE PRODUTOS");
				for (Produto p : ordem.getListaProdutos()) {
					System.out.println("Marca: " + p.getMarca());
					System.out.println("Modelo: " + p.getModelo());
					System.out.println("Valor: R$ " + p.getValor());
					System.out.println("Codigo: " + p.getCodigo());
					System.out.println("Tipo Produto: " + p.gettProduto());
					System.out.println();
				}

				System.out.println("----------------------");

			}

		}
	}
}
