package aeso;

public enum Funcao {

	MECANICO, GERENTE, CAIXA, PINTOR;
}
