package aeso;

public enum Tipo {

}
