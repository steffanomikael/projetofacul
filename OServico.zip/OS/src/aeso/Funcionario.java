package aeso;

public class Funcionario {

	private String nome;
	private int idade;
	private String matricula;
	private Funcao funcao;

	public Funcionario() {

	}

	public Funcionario(String nome, int idade, String matricula, Funcao funcao) {
		this.nome = nome;
		this.idade = idade;
		this.matricula = matricula;
		this.funcao = funcao;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public Funcao getFuncao() {
		return funcao;
	}

	public void setFuncao(Funcao funcao) {
		this.funcao = funcao;
	}

}
