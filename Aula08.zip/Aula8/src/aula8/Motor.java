package aula8;

public class Motor {

	private int NumCilindro;
	private int potencia;

	public Motor() {

	}

	public Motor(int cilindro, int potencia) {
		this.NumCilindro = cilindro;
		this.potencia = potencia;
	}

	public int getNumCilindro() {
		return NumCilindro;
	}

	public void setNumCilindro(int cilindro) {
		this.NumCilindro = cilindro;
	}

	public int getPotencia() {
		return potencia;
	}

	public void setPotencia(int potencia) {
		this.potencia = potencia;
	}

	@Override
	public String toString() {
		return " Numcilindro = " + NumCilindro + ", potencia = " + potencia + "";
	}
}
