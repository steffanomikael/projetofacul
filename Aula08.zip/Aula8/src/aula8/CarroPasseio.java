package aula8;

public class CarroPasseio extends Veiculo {

	private String cor;
	private String modelo;

	public CarroPasseio() {

	}

	public CarroPasseio(Veiculo veiculo, String cor, String modelo) {
		super(veiculo.getPeso(), veiculo.getVelocMax(), veiculo.getPreco(), veiculo.getMotor());
		this.cor = cor;
		this.modelo = modelo;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	@Override
	public String toString() {
		return super.toString() + " \nCarroPasseio cor = " + cor + ", modelo = " + modelo + "";
	}

}
