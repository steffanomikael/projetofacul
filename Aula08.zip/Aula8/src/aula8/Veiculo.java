package aula8;

public class Veiculo {
	private int peso;
	private int velocMax;
	private float preco;
	private Motor motor;

	public Veiculo() {

	}

	public Veiculo(int peso, int velocMax, float preco, Motor motor) {
		this.peso = peso;
		this.velocMax = velocMax;
		this.preco = preco;
		this.motor = motor;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public int getVelocMax() {
		return velocMax;
	}

	public void setVelocMax(int velocMax) {
		this.velocMax = velocMax;
	}

	public float getPreco() {
		return preco;
	}

	public void setPreco(float preco) {
		this.preco = preco;
	}

	public Motor getMotor() {
		return motor;
	}

	public void setMotor(Motor motor) {
		this.motor = motor;
	}

	@Override
	public String toString() {
		return "Veiculo peso = " + peso + "KG, velocMax = " + velocMax + " Km/h, preco = R$ " + preco + " \nMotor ="
				+ motor + "";
	}

}
