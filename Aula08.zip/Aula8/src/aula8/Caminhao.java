package aula8;

public class Caminhao extends Veiculo {

	private int toneladas;
	private int alturaMax;
	private int comprimento;

	public Caminhao() {

	}

	public Caminhao(Veiculo veiculo, int toneladas, int alturaMax, int comprimento) {
		super(veiculo.getPeso(), veiculo.getVelocMax(), veiculo.getPreco(), veiculo.getMotor());
		this.toneladas = toneladas;
		this.alturaMax = alturaMax;
		this.comprimento = comprimento;
	}

	public int getToneladas() {
		return toneladas;
	}

	public void setToneladas(int toneladas) {
		this.toneladas = toneladas;
	}

	public int getAlturaMax() {
		return alturaMax;
	}

	public void setAlturaMax(int alturaMax) {
		this.alturaMax = alturaMax;
	}

	public int getComprimento() {
		return comprimento;
	}

	public void setComprimento(int comprimento) {
		this.comprimento = comprimento;
	}

	@Override
	public String toString() {
		return super.toString() + " \nCaminhao toneladas = " + toneladas + ", alturaMax = " + alturaMax
				+ ", comprimento = " + comprimento + "";
	}

}
