package aula8;

public class Principal {
	public static void main(String[] args) {

		System.out.println("Exercicio 01 abaixo:");
		Motor motor = new Motor(56, 320);

		Veiculo veiculo = new Veiculo(60, 70, 205.468f, motor);
		System.out.println(veiculo);
		System.out.println();

		// carroPasseio

		System.out.println("Exercicio 02 abaixo:");
		CarroPasseio carroPasseio = new CarroPasseio(veiculo, "Azul", "BMW");
		System.out.println(carroPasseio);
		System.out.println();

		// continua��o do exercicio 02
		// parte caminh�o

		Caminhao caminhao = new Caminhao(veiculo, 20, 4, 7);
		System.out.println(caminhao);

	}

}
