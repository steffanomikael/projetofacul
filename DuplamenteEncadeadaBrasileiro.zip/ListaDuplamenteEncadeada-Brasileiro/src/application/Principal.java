package application;

import services.ListaDuplamenteEncadeadaRecursiva;

public class Principal {
	public static void main(String[] args) {
		ListaDuplamenteEncadeadaRecursiva recursiva = new ListaDuplamenteEncadeadaRecursiva("Jo�o Andrade");
		recursiva.inserir("St�ffano");
		recursiva.inserir("Jonatas");
		recursiva.inserir("Momo");
		recursiva.remover("Nays");
		recursiva.imprimir();
	}
}
