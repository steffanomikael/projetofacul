package services;

public class ListaDuplamenteEncadeadaRecursiva {
	private String dado;
	private ListaDuplamenteEncadeadaRecursiva anterior;
	private ListaDuplamenteEncadeadaRecursiva proximo;

	public ListaDuplamenteEncadeadaRecursiva(String dado) {
		this.dado = dado;
	}

	public void inserir(String dado) {
		if (this.proximo == null) {
			this.proximo = new ListaDuplamenteEncadeadaRecursiva(dado);
			this.proximo.anterior = this;
		} else {
			this.proximo.inserir(dado);
		}
	}

	public void remover(String dado) {
		if (this.dado.equals(dado) || this.dado == dado) {
			if (this.anterior == null) {
				if (this.proximo == null) {
					this.dado = null;
				} else {
					this.dado = this.proximo.dado;
					if (this.proximo.proximo != null) {
						this.proximo.proximo.anterior = this;
						this.proximo = this.proximo.proximo;
					} else {
						this.proximo.anterior = null;
						this.proximo = null;
					}
				}
			} else {
				if (this.proximo == null) {
					this.anterior.proximo = null;
					this.anterior = null;
				} else {
					this.proximo.anterior = this.anterior;
					this.anterior.proximo = this.proximo;
				}
			}
		} else if (this.proximo != null) {
			this.proximo.remover(dado);
		} else {
			throw new RuntimeException("Objeto n�o existente!");
		}
	}

	public void imprimir() {
		System.out.println(dado != null ? dado : "");
		if (this.proximo != null) {
			this.proximo.imprimir();
		}
	}
}
