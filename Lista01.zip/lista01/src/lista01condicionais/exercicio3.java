package lista01condicionais;

import java.util.Scanner;

public class exercicio3 {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);

		String tipo;

		System.out.print("Entre com um numero: ");
		int numero = scan.nextInt();

		tipo = (numero % 2 == 0) ? "Par" : "Impar";

		System.out.println("O numero digitado � " + tipo);

		scan.close();

	
	}
}
