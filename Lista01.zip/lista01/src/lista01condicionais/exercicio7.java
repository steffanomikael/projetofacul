package lista01condicionais;

import java.util.Scanner;

public class exercicio7 {
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		int qtdNegativos = 0;
		for (int i = 1; i <= 5; i++) {
			int a = scan.nextInt();
			if (a < 0) {
				qtdNegativos++;
			}
		}

		System.out.println("A quantidade de numeros negativos digitados foi " + qtdNegativos);

		scan.close();
	}
}
	