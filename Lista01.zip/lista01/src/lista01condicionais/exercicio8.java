package lista01condicionais;

import java.util.Scanner;

public class exercicio8 {
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		float chico = 1.50f;
		float ze = 1.10f;
		int qtdAno = 0;

		while (ze <= chico) {
			chico += 0.02;
			ze += 0.03;
			qtdAno++;
		}

		System.out.println("� necessario " + qtdAno + " ano(s) para que ze passe de chico na altura");

		scan.close();

	}
}
