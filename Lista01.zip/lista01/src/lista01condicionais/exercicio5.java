package lista01condicionais;

import java.util.Scanner;

public class exercicio5 {
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		float n1, n2, n3, n4;
		String situa��o = "";
		n1 = scan.nextFloat();
		n2 = scan.nextFloat();
		n3 = scan.nextFloat();
		n4 = scan.nextFloat();

		if ((n1 < n2) && (n1 < n3) && (n1 < n4)) {
			situa��o = "O numero " + n1 + " � o menor de todos os numeros";
		} else if ((n2 < n1) && (n2 < n3) && (n2 < n4)) {
			situa��o = "O numero " + n2 + " � o menor de todos os numeros";
		} else if ((n3 < n1) && (n3 < n2) && (n3 < n4)) {
			situa��o = "O numero " + n3 + " � o menor de todos os numeros";
		} else if ((n4 < n1) && (n4 < n2) && (n4 < n3)) {
			situa��o = "O numero " + n4 + " � o menor de todos os numeros";
		}

		System.out.println(situa��o);

		scan.close();
	}

}