package lista01condicionais;

import java.util.Scanner;

public class exercicio6 {
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		float n1, n2;
		float media;
		String situacao = "";
		System.out.print("Entre com a nota1: ");
		n1 = scan.nextFloat();
		System.out.print("Entre com a nota2: ");
		n2 = scan.nextFloat();

		media = (n1 + n2) / 2;

		if (media >= 7.0) {
			situacao = "Aprovado";
		} else if (media >= 4 && media < 7.0) {
			System.out.print("Entre com a nota da prova final: ");
			float notaFinal = scan.nextFloat();
			float mediaFinal = notaFinal + media;
			if (mediaFinal >= 10) {
				situacao = "Aprovado";
			} else {
				situacao = "Reprovado";
			}
		} else {
			situacao = "Reprovado";
		}

		System.out.println();
		System.out.println("A situa��o do aluno �: " + situacao);

		scan.close();

	}

}
