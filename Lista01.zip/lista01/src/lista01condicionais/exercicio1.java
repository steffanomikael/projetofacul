package lista01condicionais;

import java.util.Scanner;

public class exercicio1 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		float media;
		float nota1, nota2, nota3, nota4;
		nota1 = scan.nextFloat();
		nota2 = scan.nextFloat();
		nota3 = scan.nextFloat();
		nota4 = scan.nextFloat();

		media = ((nota1 * 2.0f) + (nota2 * 3.0f) + (nota3 * 1.0f) + (nota4 * 4.0f)) / (2.0f + 3.0f + 1.0f + 4.0f);

		System.out.println("Resultado da media �: " + String.format("%.2f", media));

		scan.close();
	}
}
