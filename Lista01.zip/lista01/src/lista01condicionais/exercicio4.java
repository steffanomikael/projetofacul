package lista01condicionais;

import java.util.Scanner;

public class exercicio4 {
	Scanner scan = new Scanner(System.in);

	float n1, n2;
	n1 = scan.nextFloat();
	n2 = scan.nextFloat();

	if (n1 < n2) {
		System.out.println("O numero " + n1 + " � menor que " + n2);
	} else if (n2 < n1) {
		System.out.println("O numero " + n2 + " � menor que " + n1);
	} else {
		System.out.println("Os numeros digitados s�o iguais!");
	}

	scan.close();
}

}
