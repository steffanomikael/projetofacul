package principal.br.com.aeso;

import br.com.aeso.calculadora.Calculadora;
import br.com.aeso.implementacao.CalculadoraImplementacao;

public class EstruturaDados {
	public static void main(String[] args) {
		
		Calculadora calculadora = new CalculadoraImplementacao();
		double resultado1 = calculadora.somar(5, 5);
		System.out.println("Resultado da soma: " + resultado1);
		System.out.println();
		
		double resultado2 = calculadora.subtrair(10, 5);
		System.out.println("Resultado da subtra��o: " + resultado2);
		System.out.println();
		
		double resultado3 = calculadora.multiplicar(8, 2);
		System.out.println("Resultado da multiplica��o: " + resultado3);
		System.out.println();
		
		double resultado4 = calculadora.dividir(50, 5);
		System.out.println("Resultado da divis�o: " + resultado4);
	}

}
