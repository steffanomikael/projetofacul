package br.com.aeso.calculadora;

public interface Calculadora {

	double somar(double valor1, double valor2);
	double subtrair(double valor1, double valor2);
	double multiplicar(double valor1, double valor2);
	double dividir(double valor1, double valor2);
}
