package br.com.aeso.implementacao;

import br.com.aeso.calculadora.Calculadora;

public class CalculadoraImplementacao implements Calculadora {

	@Override
	public double somar(double valor1, double valor2) {
		System.out.println("Vers�o 1 - Calculadora implementa��o");
		return valor1+valor2;
	}

	@Override
	public double subtrair(double valor1, double valor2) {
		System.out.println("Vers�o 1 - Calculadora implementa��o");
		return valor1-valor2;
	}

	@Override
	public double multiplicar(double valor1, double valor2) {
		System.out.println("Vers�o 1 - Calculadora Implementa��o");
		return valor1*valor2;
	}

	@Override
	public double dividir(double valor1, double valor2) {
			System.out.println("Vers�o 1 - Calculadora implementa��o");
		return valor1/valor2;
	}	
}
