package br.aeso.exercicio08;

import br.aeso.exercicio07.Funcionario;

public class Relatorio {

	public void gerencialFuncionario(Funcionario funcionario) {
		System.out.println(funcionario.getClass().getSimpleName());
		System.out.println(funcionario.getInfo());
		System.out.println(funcionario.getGratificacao());
	}

}
