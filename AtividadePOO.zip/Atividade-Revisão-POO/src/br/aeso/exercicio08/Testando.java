package br.aeso.exercicio08;

import br.aeso.exercicio07.Monitor;

public class Testando {
	public static void main(String[] args) {
		Monitor monitor = new Monitor("Jo�o Andrade", 13000.0, 14);
		Relatorio relatorio = new Relatorio();

		relatorio.gerencialFuncionario(monitor);
	}
}
