package br.aeso.exercicio07;

public class Monitor extends Funcionario {
	private Integer horas;

	public Monitor(String nome, Double salario, Integer horas) {
		super(nome, salario);
		this.setHoras(horas);
	}

	public Integer getHoras() {
		return horas;
	}

	public void setHoras(Integer horas) {
		this.horas = horas;
	}

	@Override
	public Double getGratificacao() {
		return super.getSalario() + (horas * 10);
	}

//	@Override
//	public String getInfo() {
//		String mensagem = "Nome: " + super.getNome() + ", sou monitor com " + horas + "h/aula e Sal�rio R$ "
//				+ String.format("%.2f", getGratificacao());
//
//		return mensagem;
//	}
}
