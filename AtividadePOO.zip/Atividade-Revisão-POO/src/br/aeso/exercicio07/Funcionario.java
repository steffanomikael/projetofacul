package br.aeso.exercicio07;

public abstract class Funcionario {
	private String nome;
	private Double salario;

	public Funcionario(String nome, Double salario) {
		this.setNome(nome);
		this.setSalario(salario);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Double getSalario() {
		return salario;
	}

	public void setSalario(Double salario) {
		this.salario = salario;
	}

	public abstract Double getGratificacao();

	public String getInfo() {
		return "Nome: " + this.nome + " Salario: R$ " + String.format("%.2f", getGratificacao());
	}

}
