package br.aeso.exercicio01;

public class PessoaJuridica {
	private String nome;
	private String cnpj;
	private String inscricaoEstadual;
	private String endereco;
	private String bairro;
	private String cidade;

	public PessoaJuridica(String nome, String cnpj, String inscricaoEstadual, String endereco, String bairro,
			String cidade) {
		this.setNome(nome);
		this.setCnpj(cnpj);
		this.setInscricaoEstadual(inscricaoEstadual);
		this.setEndereco(endereco);
		this.setBairro(bairro);
		this.setCidade(cidade);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDocumento() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getInscricaoEstadual() {
		return inscricaoEstadual;
	}

	public void setInscricaoEstadual(String inscricaoEstadual) {
		this.inscricaoEstadual = inscricaoEstadual;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public void formatarDocumento() {

	}

	@Override
	public String toString() {
		return "PessoaJuridica [nome=" + nome + ", cnpj=" + cnpj + ", inscricaoEstadual=" + inscricaoEstadual
				+ ", endereco=" + endereco + ", bairro=" + bairro + ", cidade=" + cidade + "]";
	}

}
