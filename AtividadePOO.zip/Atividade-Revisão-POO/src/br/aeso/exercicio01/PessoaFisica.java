package br.aeso.exercicio01;

public class PessoaFisica {
	private String nome;
	private String cpf;
	private String endereco;
	private String bairro;
	private String cidade;

	public PessoaFisica(String nome, String cpf, String endereco, String bairro, String cidade) {
		this.setNome(nome);
		this.setCpf(cpf);
		this.setEndereco(endereco);
		this.setBairro(bairro);
		this.setCidade(cidade);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDocumento() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public void formatarDocumento() {

	}

	@Override
	public String toString() {
		return "PessoaFisica [nome=" + nome + ", cpf=" + cpf + ", endereco=" + endereco + ", bairro=" + bairro
				+ ", cidade=" + cidade + "]";
	}

}
