package br.aeso.exercicio11;

public class TesteInterface {

	public static void main(String[] args) {
		Quadrado quadrado = new Quadrado(4);
		Cubo cubo = new Cubo(4);

		imprimirInformacao(quadrado);
		imprimirInformacao(cubo);
	}

	public static void imprimirInformacao(AreaCalculavel areaCalculavel) {
		System.out.println(areaCalculavel.getClass().getSimpleName());
		System.out.println(areaCalculavel.calcularArea());
	}
}
