package br.aeso.exercicio11;

public class Cubo implements AreaCalculavel {
	private double lado;

	public Cubo(double lado) {
		this.setLado(lado);
	}

	public double getLado() {
		return lado;
	}

	public void setLado(double lado) {
		this.lado = lado;
	}

	@Override
	public double calcularArea() {
		return lado * lado * lado;
	}

}
