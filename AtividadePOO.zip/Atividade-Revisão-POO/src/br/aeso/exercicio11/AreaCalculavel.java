package br.aeso.exercicio11;

public interface AreaCalculavel {
	public double calcularArea();
}
