package br.aeso.exercicio03;

public class Diretor {
	private String nome;
	private String cpf;
	private Double salario;
	private Integer qtdFuncionario;
	private String senha;

	public Diretor(String nome, String cpf, Double salario, Integer qtdFuncionario, String senha) {
		this.setNome(nome);
		this.setCpf(cpf);
		this.setSalario(salario);
		this.setQtdFuncionario(qtdFuncionario);
		this.setSenha(senha);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Double getSalario() {
		return salario;
	}

	public void setSalario(Double salario) {
		this.salario = salario;
	}

	public Integer getQtdFuncionario() {
		return qtdFuncionario;
	}

	public void setQtdFuncionario(Integer qtdFuncionario) {
		this.qtdFuncionario = qtdFuncionario;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public boolean autenticar(String senha) {
		return this.getSenha().equals(senha);
	}

}
