package br.aeso.exercicio03.impl.ex01;

public class PessoaFisica extends Pessoa {

	public PessoaFisica(String nome, String documento, Endereco endereco) {
		super(nome, documento, endereco);
	}

	@Override
	public void formatarDocumento() {

	}

}
