package br.aeso.exercicio03.impl.ex01;

public final class Endereco {
	private String rua;
	private String bairro;
	private String cidade;

	public Endereco(String rua, String bairro, String cidade) {
		this.setRua(rua);
		this.setBairro(bairro);
		this.setCidade(cidade);
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		this.rua = rua;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	@Override
	public String toString() {
		return "Endereco [rua=" + rua + ", bairro=" + bairro + ", cidade=" + cidade + "]";
	}

}
