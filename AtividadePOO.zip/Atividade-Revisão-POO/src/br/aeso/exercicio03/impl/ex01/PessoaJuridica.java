package br.aeso.exercicio03.impl.ex01;

public class PessoaJuridica extends Pessoa {
	private String inscricaoEstadual;

	public PessoaJuridica(String nome, String documento, Endereco endereco, String inscricaoEstadual) {
		super(nome, documento, endereco);
		this.setInscricaoEstadual(inscricaoEstadual);
	}

	public String getInscricaoEstadual() {
		return inscricaoEstadual;
	}

	public void setInscricaoEstadual(String inscricaoEstadual) {
		this.inscricaoEstadual = inscricaoEstadual;
	}

	@Override
	public void formatarDocumento() {

	}

}
