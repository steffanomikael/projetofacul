package br.aeso.exercicio03.impl.ex01;

public abstract class Pessoa {
	private String nome;
	private String documento;
	private Endereco endereco;

	public Pessoa(String nome, String documento, Endereco endereco) {
		this.setNome(nome);
		this.setDocumento(documento);
		this.setEndereco(endereco);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setDocumento(String documento) {
		this.documento = documento.replaceAll("[. -]", "");
	}

	public String getDocumento() {
		return documento;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public abstract void formatarDocumento();

}
