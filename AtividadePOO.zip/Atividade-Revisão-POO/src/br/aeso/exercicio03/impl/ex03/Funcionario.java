package br.aeso.exercicio03.impl.ex03;

public class Funcionario {
	private String nome;
	private String cpf;
	private Double salario;

	public Funcionario(String nome, String cpf, Double salario) {
		this.setNome(nome);
		this.setCpf(cpf);
		this.setSalario(salario);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		if (cpf.length() < 11) {
			throw new IllegalArgumentException("Cpf inv�lido!");
		}

		this.cpf = cpf.replaceAll("[. -]", "");
	}

	public Double getSalario() {
		return salario;
	}

	public void setSalario(Double salario) {
		this.salario = salario;
	}

}
