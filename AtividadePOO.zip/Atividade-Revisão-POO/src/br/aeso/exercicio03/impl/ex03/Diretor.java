package br.aeso.exercicio03.impl.ex03;

public class Diretor extends Funcionario {

	private Integer qtdFuncionario;
	private String senha;

	public Diretor(String nome, String cpf, Double salario, Integer qtdFuncionario, String senha) {
		super(nome, cpf, salario);
		this.setQtdFuncionario(qtdFuncionario);
		this.setSenha(senha);
	}

	public Integer getQtdFuncionario() {
		return qtdFuncionario;
	}

	public void setQtdFuncionario(Integer qtdFuncionario) {
		this.qtdFuncionario = qtdFuncionario;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public boolean autenticar(String senha) {
		return this.getSenha().equals(senha);
	}

}
