package br.aeso.exercicio03.impl.ex03;

public class Gerente extends Funcionario {
	private Integer qtdFuncionario;

	public Gerente(String nome, String cpf, Double salario, Integer qtdFuncionario) {
		super(nome, cpf, salario);
		this.setQtdFuncionario(qtdFuncionario);
	}

	public Integer getQtdFuncionario() {
		return qtdFuncionario;
	}

	public void setQtdFuncionario(Integer qtdFuncionario) {
		this.qtdFuncionario = qtdFuncionario;
	}

}
