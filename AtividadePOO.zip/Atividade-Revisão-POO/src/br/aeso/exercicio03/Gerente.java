package br.aeso.exercicio03;

public class Gerente {
	private String nome;
	private String cpf;
	private Double salario;
	private Integer qtdFuncionario;

	public Gerente(String nome, String cpf, Double salario, Integer qtdFuncionario) {
		this.setNome(nome);
		this.setCpf(cpf);
		this.setSalario(salario);
		this.setQtdFuncionario(qtdFuncionario);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Double getSalario() {
		return salario;
	}

	public void setSalario(Double salario) {
		this.salario = salario;
	}

	public Integer getQtdFuncionario() {
		return qtdFuncionario;
	}

	public void setQtdFuncionario(Integer qtdFuncionario) {
		this.qtdFuncionario = qtdFuncionario;
	}

}
