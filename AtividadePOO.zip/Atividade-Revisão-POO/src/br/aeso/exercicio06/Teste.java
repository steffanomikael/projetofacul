package br.aeso.exercicio06;

import br.aeso.exercicio05.Animal;
import br.aeso.exercicio05.Cachorro;
import br.aeso.exercicio05.Galinha;

public class Teste {
	public static void main(String[] args) {
		Animal cachorro = new Cachorro("Pastor Alem�o", 30, "Ra��o");
		Animal galinha = new Galinha("Galinha", 2, "Alpiste");
		
		ExibirInformacao.exibirAnimal(cachorro);
		ExibirInformacao.exibirAnimal(galinha);
		
		System.out.println("---------------------");
		
		ExibirInformacao.exibirAnimalPolimorfismo(cachorro);
		ExibirInformacao.exibirAnimalPolimorfismo(galinha);
		
	}
}
