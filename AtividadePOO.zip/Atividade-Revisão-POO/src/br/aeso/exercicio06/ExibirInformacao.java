package br.aeso.exercicio06;

import br.aeso.exercicio05.Animal;
import br.aeso.exercicio05.Cachorro;
import br.aeso.exercicio05.Galinha;

public class ExibirInformacao {

	private ExibirInformacao() {
	}

	// sem polimorfismo
	public static void exibirAnimal(Animal animal) {
		if (animal instanceof Cachorro) {
			System.out.println("Peso: " + ((Cachorro) animal).getPeso());
			animal.fazerBarulho();
		} else if (animal instanceof Galinha) {
			System.out.println("Peso: " + ((Galinha) animal).getPeso());
			animal.fazerBarulho();
		}
	}

	// com polimorfismo
	public static void exibirAnimalPolimorfismo(Animal animal) {
		System.out.println("Peso: " + animal.getPeso());
		animal.fazerBarulho();
	}
}
