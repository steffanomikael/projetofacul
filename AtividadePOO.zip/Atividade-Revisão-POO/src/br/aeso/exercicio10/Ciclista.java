package br.aeso.exercicio10;

public interface Ciclista {
	public void pedalar();
}
