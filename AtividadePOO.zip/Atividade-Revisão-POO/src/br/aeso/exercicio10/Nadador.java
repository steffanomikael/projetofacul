package br.aeso.exercicio10;

public interface Nadador {
	public void nadar();
}
