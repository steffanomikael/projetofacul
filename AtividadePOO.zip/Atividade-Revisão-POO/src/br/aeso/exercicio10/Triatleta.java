package br.aeso.exercicio10;

public class Triatleta implements Ciclista, Corredor, Nadador {
	private String nome;
	private int idade;

	public Triatleta(String nome, int idade) {
		this.setNome(nome);
		this.setIdade(idade);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	@Override
	public void nadar() {
		System.out.println("Nadando");
	}

	@Override
	public void correr() {
		System.out.println("Correndo");

	}

	@Override
	public void pedalar() {
		System.out.println("Pedalando");

	}

}
