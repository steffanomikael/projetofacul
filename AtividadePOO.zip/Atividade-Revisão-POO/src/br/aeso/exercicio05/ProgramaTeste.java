package br.aeso.exercicio05;

public class ProgramaTeste {
	public static void main(String[] args) {
		Cachorro cachorro = new Cachorro("Pastor Alem�o", 30, "Ra��o");
		Galinha galinha = new Galinha("Galinha", 2, "Alpiste");

		System.out.println(cachorro);
		System.out.println(galinha);
	}
}
