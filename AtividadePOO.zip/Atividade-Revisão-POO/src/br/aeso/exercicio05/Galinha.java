package br.aeso.exercicio05;

public class Galinha extends Animal {

	public Galinha(String nome, double peso, String comida) {
		super(nome, peso, comida);
	}

	@Override
	public void fazerBarulho() {
		System.out.println("Cocorico");
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Galinha:\n");
		builder.append("Nome: " + super.getNome() + "\n");
		builder.append("Peso: " + super.getPeso() + " kg\n");
		builder.append("Comida: " + super.getComida() + "\n");

		return builder.toString();

	}
}
