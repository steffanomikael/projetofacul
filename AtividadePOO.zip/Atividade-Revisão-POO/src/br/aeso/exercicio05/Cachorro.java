package br.aeso.exercicio05;

public class Cachorro extends Animal {

	public Cachorro(String nome, double peso, String comida) {
		super(nome, peso, comida);
	}

	@Override
	public void fazerBarulho() {
		System.out.println("Au au");
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Cachorro:\n");
		builder.append("Nome: " + super.getNome() + "\n");
		builder.append("Peso: " + super.getPeso() + " kg\n");
		builder.append("Comida: " + super.getComida() + "\n");

		return builder.toString();

	}

}
