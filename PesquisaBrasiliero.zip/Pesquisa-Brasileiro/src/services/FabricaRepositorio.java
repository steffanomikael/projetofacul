package services;

import exceptions.ObjetoJaExistenteException;
import exceptions.ObjetoNaoExistenteException;

public class FabricaRepositorio implements IListaEstatica {
	private static final int MAX_LIST = 100;
	private Integer[] dados = new Integer[MAX_LIST];
	private int tamanhoLista = 0;

	@Override
	public void inserir(Object object) throws ObjetoJaExistenteException {
		if (tamanhoLista == dados.length) {
			throw new RuntimeException("A lista est� cheia!");
		}

		for (int i = 0; i < dados.length; i++) {
			if (dados[i] == null) {
				dados[i] = (Integer) object;
				aumentarTamanho();
				break;
			}
		}

	}

	@Override
	public void remover(Object object) throws ObjetoNaoExistenteException {
		int i = localizarIndice(object);

		if (i == -1) {
			throw new ObjetoNaoExistenteException("O objeto n�o existe!");
		}

		dados[i] = null;
		diminuirTamanho();
		Integer[] temp = new Integer[MAX_LIST];
		int tamanhoTemp = 0;
		for (int j = 0; j < dados.length; j++) {
			if (dados[j] != null) {
				temp[tamanhoTemp++] = dados[j];
			}
		}

		for (int j = 0; j < dados.length; j++) {
			if (dados[j] != null) {
				dados[j] = null;
			}
		}

		for (int j = 0; j < temp.length; j++) {
			if (temp[j] != null) {
				dados[j] = temp[j];
			}
		}

	}

	public Integer pesquisaLinear(int valor) {
		for (int i = 0; i < this.dados.length; i++) {
			if (this.dados[i] != null) {
				if (this.dados[i] == valor) {
					return this.dados[i];
				}
			}
		}

		return null;
	}

	private int tamanhoLista() {
		int tamanho = 0;
		for (int i = 0; i < this.dados.length; i++) {
			if (this.dados[i] != null) {
				tamanho++;
			}
		}

		return tamanho;
	}

	public Integer pesquisaBinaria(int valor) {
		int inicio = 0, meio = 0, fim;
		fim = tamanhoLista() - 1;

		while (inicio <= fim) {
			meio = (inicio + fim) / 2;
			if (valor < this.dados[meio]) {
				fim = meio - 1;
			} else {
				if (valor > this.dados[meio]) {
					inicio = meio + 1;
				} else {
					return this.dados[meio];
				}
			}
		}

		return -1;
	}

	@Override
	public int localizarIndice(Object object) {
		Integer pessoa = (Integer) object;

		for (int i = 0; i < dados.length; i++) {
			if (dados[i] != null && dados[i].equals(pessoa)) {
				return i;
			}
		}

		return -1;
	}

	@Override
	public Object pesquisarPorValor(Object object) throws ObjetoNaoExistenteException {
		int i = localizarIndice(object);

		if (i == -1) {
			throw new ObjetoNaoExistenteException("O objeto n�o existe na lista!");
		}

		return dados[i];
	}

	@Override
	public void alterar(Object object) throws ObjetoNaoExistenteException {
		int i = localizarIndice(object);
		if (i == -1) {
			throw new ObjetoNaoExistenteException("O objeto n�o existe na lista!");
		}

		dados[i] = (Integer) object;
	}

	public void imprimir() {
		for (int i = 0; i < dados.length; i++) {
			if (dados[i] != null)
				System.out.println(dados[i]);

		}
	}

	private void aumentarTamanho() {
		tamanhoLista++;
	}

	private void diminuirTamanho() {
		tamanhoLista--;
	}
}
