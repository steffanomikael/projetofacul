package application;

import services.FabricaRepositorio;

public class Principal {
	public static void main(String[] args) {
		try {
			FabricaRepositorio repositorio = new FabricaRepositorio();
			repositorio.inserir(11);
			repositorio.inserir(33);
			repositorio.inserir(12);
			repositorio.inserir(65);

			repositorio.imprimir();
			System.out.println("--------------------------");
			System.out.println("Pesquisas");
			System.out.println("Pesquisa linear: " + repositorio.pesquisaLinear(33));
			System.out.println("Pesquisa binaria: " + repositorio.pesquisaBinaria(12));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
